const API_BASE = 'http://localhost:5000/api';

// Helper function to get auth headers
const getAuthHeaders = (isFormData = false) => {
  const token = localStorage.getItem('token');
  const headers = {};
  
  if (!isFormData) {
    headers['Content-Type'] = 'application/json';
  }
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  
  return headers;
};

// Helper function for API calls
const apiCall = async (endpoint, options = {}) => {
  const isFormData = options.body instanceof FormData;
  
  const response = await fetch(`${API_BASE}${endpoint}`, {
    credentials: 'include',
    headers: getAuthHeaders(isFormData),
    ...options,
    headers: {
      ...getAuthHeaders(isFormData),
      ...options.headers
    }
  });
  
  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Network error' }));
    throw new Error(error.message || `HTTP ${response.status}`);
  }
  
  return response.json();
};

// Auth API calls
export const authAPI = {
  login: async (email, password) => {
    return apiCall('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });
  },
  
  register: async (userData) => {
    return apiCall('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData)
    });
  },
  
  logout: async () => {
    return apiCall('/auth/logout', { method: 'POST' });
  }
};

// User API calls
export const userAPI = {
  getAll: () => apiCall('/users'),
  getById: (id) => apiCall(`/users/${id}`),
  update: (id, userData) => {
    // Check if userData is FormData (for file uploads)
    if (userData instanceof FormData) {
      console.log('userAPI.update - sending FormData for user:', id);
      return apiCall(`/users/${id}`, {
        method: 'PUT',
        body: userData,
        // Don't set Content-Type header for FormData - browser will set it with boundary
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token') || ''}`
        }
      });
    } else {
      console.log('userAPI.update - sending JSON data for user:', id);
      return apiCall(`/users/${id}`, {
        method: 'PUT',
        body: JSON.stringify(userData)
      });
    }
  },
  delete: (id) => apiCall(`/users/${id}`, { method: 'DELETE' }),
  getProjects: (id) => apiCall(`/users/${id}/projects`),
  addFriend: (userId, friendId) => apiCall(`/users/${userId}/friends`, {
    method: 'POST',
    body: JSON.stringify({ friendId })
  }),
  removeFriend: (userId, friendId) => apiCall(`/users/${userId}/friends/${friendId}`, {
    method: 'DELETE'
  })
};

// Project API calls
export const projectAPI = {
  getAll: () => apiCall('/projects'),
  getById: (id) => apiCall(`/projects/${id}`),
  create: (projectData) => apiCall('/projects', {
    method: 'POST',
    body: JSON.stringify(projectData)
  }),
  update: (id, projectData) => apiCall(`/projects/${id}`, {
    method: 'PUT',
    body: JSON.stringify(projectData)
  }),
  delete: (id) => apiCall(`/projects/${id}`, { method: 'DELETE' }),
  checkout: (id) => apiCall(`/projects/${id}/checkout`, { method: 'POST' }),
  checkin: (id, checkinData) => apiCall(`/projects/${id}/checkin`, {
    method: 'POST',
    body: JSON.stringify(checkinData || {})
  }),
  cancelCheckout: (id) => apiCall(`/projects/${id}/cancel-checkout`, { method: 'POST' })
};

// Checkin API calls
export const checkinAPI = {
  getAll: () => apiCall('/checkins'),
  getByProject: (projectId) => apiCall(`/checkins/project/${projectId}`),
  getByUser: (userId) => apiCall(`/checkins/user/${userId}`)
};

// Search API calls
export const searchAPI = {
  search: (query) => apiCall(`/search?q=${encodeURIComponent(query)}`)
};

// Posts API calls
export const postsAPI = {
  getByProject: (projectId) => apiCall(`/posts/project/${projectId}`),
  create: (postData) => apiCall('/posts', {
    method: 'POST',
    body: JSON.stringify(postData)
  }),
  delete: (id) => apiCall(`/posts/${id}`, { method: 'DELETE' })
};

export default {
  authAPI,
  userAPI,
  projectAPI,
  checkinAPI,
  searchAPI
};