import React, { useState, useEffect } from "react";
import { createRoot } from "react-dom/client";
import HeaderNav from "./components/HeaderNav.jsx";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import ProjectPreview from "./components/ProjectPreview.jsx";
import ProfilePreview from "./components/ProfilePreview.jsx";
import CreateProjectForm from "./components/CreateProjectForm.jsx";
import EditProfileForm from "./components/EditProfileForm.jsx";
import EditProjectForm from "./components/EditProjectForm.jsx";
import LoginForm from "./components/LoginForm.jsx";
import SignUpForm from "./components/SignUpForm.jsx";
import SplashPage from "./pages/SplashPage.js";
import HomePage from "./pages/HomePage.js";
import ProfilePage from "./pages/ProfilePage.js";
import Profile from "./components/Profile.jsx";
import ProjectPage from "./pages/ProjectPage.js";
import ProjectViewPage from "./pages/ProjectViewPage.js";
import Project from "./components/Project.jsx";
import FeedItem from "./components/FeedItem.jsx";
import FeedPage from "./pages/FeedPage.js";
import FeedList from "./components/FeedList.jsx";
import "./global.css";
import SearchInput from "./components/SearchInput.jsx";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(() => !!localStorage.getItem('user'));
  const [showSignUp, setShowSignUp] = useState(false);

  useEffect(() => {
    const handler = () => setIsLoggedIn(!!localStorage.getItem('user'));
    window.addEventListener('storage', handler);
    return () => window.removeEventListener('storage', handler);
  }, []);

  const handleLogin = (user) => {
    setIsLoggedIn(true);
    setShowSignUp(false);
  };

  const handleSignUp = (user) => {
    setIsLoggedIn(true);
    setShowSignUp(false);
  };

  const handleLogout = () => {
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    setIsLoggedIn(false);
  };

  return (
    <>
      <HeaderNav isLoggedIn={isLoggedIn} onLogout={handleLogout} />
      <main>
        {!isLoggedIn ? (
          <div>
            {!showSignUp ? (
              <div>
                <LoginForm onLogin={handleLogin} />
                <div style={{ textAlign: 'center', marginTop: '1rem' }}>
                  <p>Don't have an account? 
                    <button 
                      onClick={() => setShowSignUp(true)}
                      style={{ marginLeft: '0.5rem', background: 'none', border: 'none', color: '#007bff', textDecoration: 'underline', cursor: 'pointer' }}
                    >
                      Sign Up
                    </button>
                  </p>
                </div>
              </div>
            ) : (
              <div>
                <SignUpForm onSignUp={handleSignUp} />
                <div style={{ textAlign: 'center', marginTop: '1rem' }}>
                  <p>Already have an account? 
                    <button 
                      onClick={() => setShowSignUp(false)}
                      style={{ marginLeft: '0.5rem', background: 'none', border: 'none', color: '#007bff', textDecoration: 'underline', cursor: 'pointer' }}
                    >
                      Login
                    </button>
                  </p>
                </div>
              </div>
            )}
          </div>
        ) : (
          <Routes>
            <Route path="/" element={<SplashPage />} />
            <Route path="/home" element={<HomePage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/profile/:id" element={<ProfilePage />} />
            <Route path="/projects" element={<ProjectPage />} />
            <Route path="/project/:id" element={<ProjectViewPage />} />
            <Route path="/feed" element={<FeedPage />} />
          </Routes>
        )}
      </main>
    </>
  );
}

const container = document.getElementById("root");
const root = createRoot(container);
root.render(
  //STARTS PROCESS OF RENDERING REACT ELEMENTS INTO DOM
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);
