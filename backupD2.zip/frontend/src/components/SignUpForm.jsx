import React, { useState } from 'react';
import "../css/SignUpForm.css";

export default function SignUpForm({ onSignUp }) {
  const [username, setUsername] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [bio, setBio] = useState('');
  const [error, setError] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    
    if (password !== confirm) {
      setError('Passwords dont match.');
      return;
    }
    
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    
    try {
      const response = await fetch('http://localhost:5000/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ username, name, email, password, bio }),
      });
      
      const data = await response.json();
      
      if (response.ok && data.user) {
        localStorage.setItem('user', JSON.stringify(data.user));
        localStorage.setItem('token', data.token);
        onSignUp?.(data.user);
      } else {
        setError(data.message || 'Sign up failed.');
      }
    } catch (err) {
      console.error('Signup error:', err);
      setError('Network error. Please try again.');
    }
  };

  return (
    <div className="signup-form-container">
      <form onSubmit={submit} aria-label="Sign up">
        <fieldset>
          <legend>Sign Up</legend>
          <label>
            Username
            <input
              type="text"
              value={username}
              placeholder="Enter username"
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </label>
          <label>
            Full Name
            <input
              type="text"
              value={name}
              placeholder="Enter your full name"
              onChange={(e) => setName(e.target.value)}
              required
            />
          </label>
          <label>
            Email
            <input
              type="email"
              value={email}
              placeholder="imy220@pain.com"
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </label>
          <label>
            Bio
            <textarea
              value={bio}
              placeholder="Tell us about yourself"
              onChange={(e) => setBio(e.target.value)}
              rows="3"
            />
          </label>
          <label>
            Password
            <input
              type="password"
              value={password}
              placeholder="Create your password here"
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </label>
          <label>
            Confirm Password
            <input
              type="password"
              value={confirm}
              placeholder="Repeat password"
              onChange={(e) => setConfirm(e.target.value)}
              required
            />
          </label>
          {error && <div style={{ color: 'red', marginBottom: '10px' }}>{error}</div>}
          <button type="submit">Create account</button>
        </fieldset>
      </form>
    </div>
  );
}