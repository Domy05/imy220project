import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { projectAPI, userAPI } from '../utils/api';

export default function FeedItem({ message }) {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadMessageData();
  }, [message]);

  const loadMessageData = async () => {
    try {
      setLoading(true);
      
      // Load user and project data in parallel
      const [userData, projectData] = await Promise.all([
        message.user ? userAPI.getById(message.user) : Promise.resolve(null),
        message.project ? projectAPI.getById(message.project) : Promise.resolve(null)
      ]);
      
      setUser(userData);
      setProject(projectData);
    } catch (err) {
      console.error('Error loading message data:', err);
    } finally {
      setLoading(false);
    }
  };

  const dateString = message.createdAt || message.time || message.date;
  
  if (loading) {
    return (
      <div
        style={{
          border: '1px solid #ddd',
          padding: '1rem',
          borderRadius: '8px',
          backgroundColor: '#f9f9f9',
          marginBottom: '1rem',
        }}
      >
        <p>Loading...</p>
      </div>
    );
  }
  return (
    <div
      style={{
        border: '1px solid #ddd',
        padding: '1rem',
        borderRadius: '8px',
        backgroundColor: '#d1d1d175',
        marginBottom: '1rem',
        position: 'relative'
      }}
    >
      <p style={{ margin: 0 }}>
        <strong>{user ? user.name : 'Unknown User'}</strong> checked in to project{' '}
        <strong>{project ? project.name : 'Unknown Project'}</strong>
      </p>
      <p style={{ margin: '0.5rem 0' }}>{message.message || 'Project check-in'}</p>
      {message.version && (
        <p style={{ margin: '0.5rem 0', fontSize: '0.9rem', color: '#666' }}>
          Version: {message.version}
        </p>
      )}
      <small style={{ color: '#555555ff' }}>{new Date(dateString).toLocaleString()}</small>
      {project && (
        <button
          style={{
            position: 'absolute',
            bottom: '12px',
            right: '12px',
            background: '#19325c',
            color: '#fff',
            border: 'none',
            borderRadius: '16px',
            padding: '0.4rem 1rem',
            fontWeight: 600,
            fontSize: '0.95rem',
            cursor: 'pointer',
            boxShadow: '0 1px 4px rgba(20, 40, 80, 0.08)',
            transition: 'background 0.2s, color 0.2s',
          }}
          onClick={() => navigate(`/project/${project._id}`)}
        >
          Go to Project
        </button>
      )}
    </div>
  );
}