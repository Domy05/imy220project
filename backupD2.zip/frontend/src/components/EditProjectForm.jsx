import React, { useState } from "react";
import "../css/EditProjectForm.css";

export default function EditProjectForm({ project, onSave, onCancel }) {
  const [name, setName] = useState(project?.name || "Campus Notes");
  const [description, setDescription] = useState(project?.description || "Sharing lecture notes with versioning.");
  const [tags, setTags] = useState(project?.tags?.join(", ") || "react, express");       //state for tags which are combined as a string
  const [contributors, setContributors] = useState(project?.contributors || ["messi", "jordon"]);   //stae for contributors
  const [newContributor, setNewContributor] = useState("");     //input field state for new contributor
  const [files, setFiles] = useState(project?.files || [    //project files
    { id: 'f1', path: 'file1.js', size: 1024 },
    { id: 'f2', path: 'file2.js', size: 2048 },
    { id: 'f3', path: 'server.js', size: 4096 }
  ]);

  const submit = (e) => {       //form submission
    e.preventDefault();
    onSave?.({
      name,
      description,
      tags: tags.split(",").map(t => t.trim()),     //splits tags by comma and trims the 
      contributors,
      files
    });
  };

  const addContributor = (e) => {
    e.preventDefault();
    if (newContributor && !contributors.includes(newContributor)) { //checkst that an existing one isnt added 
      setContributors([...contributors, newContributor]);   //joins new contr to the contr arr
      setNewContributor("");    //clear input box
    }
  };

  const handleFileUpload = (e) => {
    const selectedFiles = Array.from(e.target.files);
    const newFiles = selectedFiles.map((file, index) => ({
      id: `new_${Date.now()}_${index}`,
      path: file.name,
      size: file.size
    }));
    setFiles(prevFiles => [...prevFiles, ...newFiles]);
    e.target.value = ""; // Clear the input
  };

  const removeFile = (fileId) => {
    setFiles(files.filter(file => file.id !== fileId));
  };

  return (
    <div className="edit-project-form-container">
      <div className="edit-project-form-content">
        <div className="edit-project-form-left">
          <form onSubmit={submit} aria-label="Edit project">
            <fieldset>
              <legend>Edit Project</legend>
              <label>
                Project Name
                <input
                  value={name}      //input for proj name
                  onChange={e => setName(e.target.value)} //  {/*updates the name state on change*/}
                  placeholder="Name of the project"
                />
              </label>
              <label>
                Description
                <textarea
                  value={description}       //for desc
                  onChange={e => setDescription(e.target.value)}  //  {/*same here*/}
                  placeholder="Project description"
                />
              </label>
              <label>
                Tags (comma separated)
                <input
                  value={tags}      //for the tags
                  onChange={e => setTags(e.target.value)}   //same here
                  placeholder="e.g., react, express"
                />
              </label>
              <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
                <button type="submit">Save Changes</button>
                {onCancel && (
                  <button type="button" onClick={onCancel}>
                    Cancel & Go Back
                  </button>
                )}
              </div>
            </fieldset>
          </form>
        </div>
        <div className="edit-project-form-right">
          <div style={{ marginBottom: "32px" }}>
            <label><strong>Contributors</strong></label>
            <input
              type="text"
              value={newContributor}      //input for new contributor
              onChange={e => setNewContributor(e.target.value)}       //updaes new contr state on change
              placeholder="Add the name of a contributor"
              style={{ width: '100%', marginBottom: '8px' }}
            />
            <button type="button" onClick={addContributor}>Add Contributors</button>
            <ul style={{ marginTop: '12px' }}>
              {contributors.length === 0 ? (
                <li>There aren't contributors yet.</li>   //show text if none
              ) : (
                contributors.map((c, idx) => <li key={idx}>{c}</li>)    //lits all the names and sizes from the files
              )}
            </ul>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
            <label><strong>Project Files</strong></label>
            <div>
              <input
                type="file"
                id="file-upload"
                multiple
                onChange={handleFileUpload}
                style={{ display: 'none' }}
              />
              <label 
                htmlFor="file-upload"
                style={{
                  background: '#007bff',
                  color: 'white',
                  padding: '6px 12px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '0.9rem',
                  border: 'none'
                }}
              >
                Upload Files
              </label>
            </div>
          </div>
          <ul>
            {files.length === 0 ? (
              <li>No files yet.</li>
            ) : (
              files.map(file => (
                <li key={file.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                  <span>{file.path} ({file.size} bytes)</span>
                  <button 
                    type="button"
                    onClick={() => removeFile(file.id)}
                    style={{
                      background: '#dc3545',
                      color: 'white',
                      border: 'none',
                      borderRadius: '3px',
                      padding: '2px 6px',
                      cursor: 'pointer',
                      fontSize: '0.8rem'
                    }}
                  >
                    Remove
                  </button>
                </li>
              ))
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}