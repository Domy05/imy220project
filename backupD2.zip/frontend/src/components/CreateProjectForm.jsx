import React, { useState } from "react";
import "../css/CreateProjectForm.css";

export default function CreateProjectForm({ version = "1.0.0", onCreate, onCancel }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState("web");
  const [hashtags, setHashtags] = useState("");
  const [files, setFiles] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const hashtagArray = hashtags.split(",").map(t => t.trim()).filter(t => t);
      const projectData = { 
        name, 
        description, 
        type,
        hashtags: hashtagArray.map(tag => tag.startsWith('#') ? tag : `#${tag}`),
        version,
        files: files.map(f => ({ name: f.name, size: f.size }))
      };
      
      await onCreate(projectData);
    } catch (err) {
      console.error("Error creating project:", err);
      alert("Failed to create project");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFileChange = (e) => {
    const selectedFiles = Array.from(e.target.files);
    setFiles(prevFiles => [...prevFiles, ...selectedFiles]);
    e.target.value = "";
  };

  const removeFile = (index) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  return (
    <div className="create-project-form-container">
      <div className="create-project-form-content">
        <div className="create-project-form-left">
          <form onSubmit={submit} aria-label="Create project">
            <fieldset>
              <legend>Create a Project</legend>
              <label>
                Project name
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g., My Awesome Project"
                  required
                />
              </label>
              <label>
                Description
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe what this project does..."
                  required
                />
              </label>
              <label>
                Project Type
                <select 
                  value={type} 
                  onChange={(e) => setType(e.target.value)}
                  required
                >
                  <option value="web">Web Application</option>
                  <option value="mobile">Mobile App</option>
                  <option value="library">Library</option>
                  <option value="desktop">Desktop Application</option>
                  <option value="other">Other</option>
                </select>
              </label>
              <label>
                Hashtags (comma separated)
                <input
                  value={hashtags}
                  onChange={(e) => setHashtags(e.target.value)}
                  placeholder="e.g., javascript, react, nodejs"
                />
              </label>
              <label>
                <strong>Project Version:</strong> {version}
              </label>
              <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
                <button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? 'Creating...' : 'Create Project'}
                </button>
                {onCancel && (
                  <button type="button" onClick={onCancel}>
                    Cancel
                  </button>
                )}
              </div>
            </fieldset>
          </form>
        </div>
        <div className="create-project-form-right">
          <label><strong>Project Files</strong></label>
          <label>Select files to upload</label>
          <input
            type="file"
            onChange={handleFileChange}
            multiple
            style={{ marginBottom: '12px' }}
          />
          <ul>
            {files.length === 0 ? (
              <li>No files selected.</li>
            ) : (
              files.map((file, index) => (
                <li key={index} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span>{file.name} ({(file.size / 1024).toFixed(1)} KB)</span>
                  <button 
                    type="button" 
                    onClick={() => removeFile(index)}
                    style={{ background: '#dc3545', color: 'white', border: 'none', borderRadius: '3px', padding: '2px 6px', cursor: 'pointer' }}
                  >
                    ×
                  </button>
                </li>
              ))
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}