import React, { useState } from "react";
import "../css/EditProfileForm.css";

export default function EditProfileForm({ user, onSave }) { //start of the component
  const [name, setName] = useState(user.name || "");
  const [surname, setSurname] = useState(user.surname || "");
  const [languages, setLanguages] = useState(user.languages || "");
  const [profilePicture, setProfilePicture] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(user.profilePicture || user.avatarUrl || "");
  //all these states initialised by user prop

  const [friends, setFriends] = useState([  //state for friends. defualt
    "lebron",
    "shaq",
    "ronaldo",
    "steve",
    "maden",
    "shifu",
    "rugard"
  ]);
  const [newFriend, setNewFriend] = useState("");
  const [projects, setProjects] = useState([
    "imy220 D3",
    "cos214 ass2",
    "inf272 hw ass2",
    "imy220 prac4",
    "wtw285 semester prac",
    "CompareIT",
    "Task Tracker"
  ]);

  const submit = (e) => {
    e.preventDefault();
    
    console.log('Form submission - profilePicture:', profilePicture);
    
    // Create FormData if there's a profile picture, otherwise use regular object
    if (profilePicture) {
      const formData = new FormData();
      formData.append('name', name);
      formData.append('surname', surname);
      formData.append('languages', languages);
      formData.append('profilePicture', profilePicture);
      
      console.log('Sending FormData with profile picture');
      // Log FormData contents
      for (let [key, value] of formData.entries()) {
        console.log(`FormData ${key}:`, value);
      }
      
      onSave?.(formData);
    } else {
      console.log('Sending regular data (no profile picture)');
      onSave?.({ name, surname, languages, projects, friends }); //calls updated profile data ifonsave
    }
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfilePicture(file);
      
      // Create preview URL
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreviewUrl(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const addFriend = (e) => {    //function to add freinds
    e.preventDefault();
    if (newFriend) {
      setFriends([...friends, newFriend]);  //adds new friend to the array list
      setNewFriend(""); //clear the input box after
    }
  };

  return (
    <div className="edit-profile-form-container">
      <div className="edit-profile-form-content">
        <div className="edit-profile-form-left">
          <div className="user-header" style={{ flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
            <div style={{ position: 'relative', marginBottom: '0.7rem' }}>
              <img
                src={
                  previewUrl 
                    ? previewUrl 
                    : user.profilePicture 
                    ? (user.profilePicture.startsWith('http') 
                        ? user.profilePicture 
                        : `http://localhost:5000${user.profilePicture}`)
                    : user.avatarUrl 
                    ? user.avatarUrl
                    : 'https://via.placeholder.com/95'
                }  //shows user image or preview
                alt={`${user.name} user image`}   //alt text for
                width="95"
                height="95"
                style={{ borderRadius: "50%", objectFit: "cover", boxShadow: "0 2px 8px rgba(20,40,80,0.10)" }}
              />
              <label 
                htmlFor="profile-picture-input"
                style={{
                  position: 'absolute',
                  bottom: '0',
                  right: '0',
                  background: '#19325c',
                  color: 'white',
                  borderRadius: '50%',
                  width: '30px',
                  height: '30px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                  fontSize: '14px',
                  border: '2px solid white'
                }}
              >
                📷
              </label>
              <input
                id="profile-picture-input"
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                style={{ display: 'none' }}
              />
            </div>
            <span className="username" style={{ fontSize: '1.5rem', fontWeight: 700, color: '#19325c', marginTop: '0.2rem' }}>{user.username}</span>
          </div>
          <form onSubmit={submit} aria-label="Edit profile">
            <fieldset>
              <label>
                Name
                <input value={name} onChange={(e) => setName(e.target.value)} />
              </label>
              <label>
                Surname
                <input value={surname} onChange={(e) => setSurname(e.target.value)} />
              </label>
              <label>
                Languages
                <input value={languages} onChange={(e) => setLanguages(e.target.value)} placeholder="e.g., JavaScript, Python" />
              </label>
              <label>
                Projects
                <ul>
                  {projects.length === 0 ? (
                    <li>There aren't projects yet</li>       //shows this when no projects
                  ) : (
                    projects.map((proj, idx) => <li key={idx}>{proj}</li>)  //lists all projects
                  )}
                </ul>
              </label>
            </fieldset>
            <button className="save-btn" type="submit" style={{ marginTop: '2rem' }}>Save</button>
          </form>
        </div>
        <div className="edit-profile-form-right">
          <label><strong>Members</strong></label>
          <form onSubmit={addFriend} style={{ display: 'flex', gap: '8px', marginBottom: '12px' }}>
            <input
              type="text"
              value={newFriend}     //input to add new friends
              onChange={e => setNewFriend(e.target.value)}
              placeholder="Add friend username"
            />
            <button type="submit">Add Friend</button>
          </form>
          <ul>
            {friends.length === 0 ? (
              <li>You  have no friends yet</li>      //shows this if no friends
            ) : (
              friends.map((friend, idx) => <li key={idx}>{friend}</li>)     //lists all the users friends
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}