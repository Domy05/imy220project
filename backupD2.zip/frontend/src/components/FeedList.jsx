import React from 'react';
import FeedItem from './FeedItem';

export default function FeedList({ messages }) {
  return (
    <section aria-label="Feed">
      {messages.length > 0 ? (
        messages
          .sort((a, b) => new Date(b.createdAt || b.date) - new Date(a.createdAt || a.date))
          .map(msg => <FeedItem key={msg._id || msg.id} message={msg} />)
      ) : (
        <p>No recent activity.</p>
      )}
    </section>
  );
}