import React from "react";
import "../css/ProfilePreview.css";
import { users } from "../data/dummyData"; //gets list of users from dummyData file

export default function ProfilePreview({ user }) {
  return (
    <article className="profile-preview"
      role="article"
      aria-labelledby={`user-${user.id}-name`}
    >
      <img
        src={user.avatarUrl}
        alt={`Avatar of ${user.name}`}
        width="48"
        height="48"
        style={{ borderRadius: "50%" }}
      />
      <div>
        <h4 id={`user-${user.id}-name`} style={{ margin: 0 }}>
          {user.name} <small>@{user.username}</small>
        </h4>
        <p style={{ margin: 0 }}>{user.bio}</p>
      </div>
    </article>
  );
}
