import React, { useState, useEffect } from 'react';
import { postsAPI, checkinAPI } from '../utils/api';
import './ProjectFeed.css';

export default function ProjectFeed({ projectId }) {
  const [posts, setPosts] = useState([]);
  const [checkins, setCheckins] = useState([]);
  const [newPost, setNewPost] = useState('');
  const [loading, setLoading] = useState(true);
  const [posting, setPosting] = useState(false);

  useEffect(() => {
    if (projectId) {
      loadFeedData();
    }
  }, [projectId]);

  const loadFeedData = async () => {
    try {
      setLoading(true);
      const [postsData, checkinsData] = await Promise.all([
        postsAPI.getByProject(projectId),
        checkinAPI.getByProject(projectId)
      ]);
      
      setPosts(postsData || []);
      setCheckins(checkinsData || []);
    } catch (err) {
      console.error('Error loading project feed:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitPost = async (e) => {
    e.preventDefault();
    if (!newPost.trim()) return;

    try {
      setPosting(true);
      const postData = {
        projectId,
        message: newPost.trim(),
        type: 'post'
      };
      
      const createdPost = await postsAPI.create(postData);
      setPosts([createdPost, ...posts]);
      setNewPost('');
    } catch (err) {
      console.error('Error creating post:', err);
      alert('Failed to create post');
    } finally {
      setPosting(false);
    }
  };

  const handleDeletePost = async (postId) => {
    if (!window.confirm('Are you sure you want to delete this post?')) return;

    try {
      await postsAPI.delete(postId);
      setPosts(posts.filter(post => post._id !== postId));
    } catch (err) {
      console.error('Error deleting post:', err);
      alert('Failed to delete post');
    }
  };

  // Combine posts and checkins and sort by date
  const feedItems = [
    ...posts.map(post => ({ ...post, itemType: 'post' })),
    ...checkins.map(checkin => ({ ...checkin, itemType: 'checkin' }))
  ].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = (now - date) / (1000 * 60 * 60);
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${Math.floor(diffInHours)}h ago`;
    if (diffInHours < 168) return `${Math.floor(diffInHours / 24)}d ago`;
    return date.toLocaleDateString();
  };

  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');

  return (
    <div className="project-feed">
      <div className="project-feed-header">
        <h3>Project Feed</h3>
        <p>Updates, posts, and check-ins for this project</p>
      </div>

      {/* Post Input */}
      <form onSubmit={handleSubmitPost} className="post-input-form">
        <div className="post-input-container">
          <textarea
            value={newPost}
            onChange={(e) => setNewPost(e.target.value)}
            placeholder="Share an update about this project..."
            className="post-input"
            rows="3"
            disabled={posting}
          />
          <button 
            type="submit" 
            disabled={!newPost.trim() || posting}
            className="post-submit-btn"
          >
            {posting ? 'Posting...' : 'Post Update'}
          </button>
        </div>
      </form>

      {/* Feed Items */}
      <div className="feed-items">
        {loading ? (
          <div className="feed-loading">Loading project feed...</div>
        ) : feedItems.length === 0 ? (
          <div className="feed-empty">
            <p>No activity yet. Be the first to post an update!</p>
          </div>
        ) : (
          feedItems.map((item) => (
            <div key={`${item.itemType}-${item._id}`} className={`feed-item feed-item-${item.itemType}`}>
              <div className="feed-item-header">
                <div className="feed-item-user">
                  <img
                    src={
                      item.user?.profilePicture 
                        ? (item.user.profilePicture.startsWith('http') 
                            ? item.user.profilePicture 
                            : `http://localhost:5000${item.user.profilePicture}`)
                        : item.user?.avatarUrl 
                        ? item.user.avatarUrl
                        : `https://ui-avatars.com/api/?name=${encodeURIComponent(item.user?.name || 'User')}&background=random`
                    }
                    alt={`${item.user?.name || 'User'} avatar`}
                    className="feed-item-avatar"
                  />
                  <div className="feed-item-user-info">
                    <span className="feed-item-username">{item.user?.name || 'Unknown User'}</span>
                    <span className="feed-item-time">{formatDate(item.createdAt)}</span>
                  </div>
                </div>
                <div className="feed-item-type">
                  {item.itemType === 'post' && <span className="feed-type-badge post">📝 Post</span>}
                  {item.itemType === 'checkin' && <span className="feed-type-badge checkin">✅ Check-in</span>}
                </div>
                {item.itemType === 'post' && item.user?._id === currentUser._id && (
                  <button 
                    onClick={() => handleDeletePost(item._id)}
                    className="feed-item-delete"
                    title="Delete post"
                  >
                    🗑️
                  </button>
                )}
              </div>
              <div className="feed-item-content">
                <p>{item.message}</p>
                {item.itemType === 'checkin' && item.version && (
                  <div className="checkin-version">Version: {item.version}</div>
                )}
                {item.itemType === 'checkin' && item.files && item.files.length > 0 && (
                  <div className="checkin-files">
                    <strong>Files:</strong> {item.files.join(', ')}
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}