import React, { useState, useEffect } from "react";
import { userAPI, projectAPI } from "../utils/api";
import { useNavigate } from "react-router-dom";
import "../css/ProjectPreview.css";

function formatDate(iso) {
  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}

export default function ProjectPreview({ project, onProjectUpdate }) {
  const [owner, setOwner] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const loadOwner = async () => {
      try {
        const userData = await userAPI.getById(project.owner);
        setOwner(userData);
      } catch (err) {
        console.error('Error loading project owner:', err);
      }
    };
    
    if (project.owner) {
      loadOwner();
    }
  }, [project.owner]);

  const handleViewProject = () => {
    navigate(`/project/${project._id}`);
  };

  const handleEditProject = () => {
    // Navigate to edit project page or show edit form
    navigate(`/project/${project._id}/edit`);
  };

  const handleCheckoutProject = async () => {
    try {
      setLoading(true);
      const result = await projectAPI.checkout(project._id);
      
      if (result.success) {
        alert(`Successfully checked out project: ${project.name}`);
        // Update the project in parent component if callback provided
        if (onProjectUpdate) {
          onProjectUpdate(result.project);
        }
        // Optionally reload the page to reflect changes
        window.location.reload();
      }
    } catch (err) {
      console.error('Error checking out project:', err);
      
      // Handle specific error messages
      if (err.message.includes('403')) {
        alert('You do not have permission to checkout this project. You must be a project member.');
      } else if (err.message.includes('400')) {
        alert('This project is already checked out by someone else.');
      } else {
        alert('Failed to checkout project. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleCheckinProject = async () => {
    const message = prompt('Enter a check-in message describing your changes:');
    if (!message) {
      alert('Check-in cancelled. A message is required.');
      return;
    }

    try {
      setLoading(true);
      const checkinData = {
        message: message,
        version: project.version || '1.0.0'
      };
      
      const result = await projectAPI.checkin(project._id, checkinData);
      
      if (result.success) {
        alert(`Successfully checked in project: ${project.name}`);
        // Update the project in parent component if callback provided
        if (onProjectUpdate) {
          // The project should now be available for checkout again
          const updatedProject = { ...project, checkedOut: false, checkedOutBy: null };
          onProjectUpdate(updatedProject);
        }
        // Reload to reflect changes
        window.location.reload();
      }
    } catch (err) {
      console.error('Error checking in project:', err);
      alert('Failed to check in project. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Check if current user has this project checked out
  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
  const userId = currentUser._id || currentUser.id || currentUser.userId;
  const isCheckedOutByCurrentUser = project.checkedOut && 
    project.checkedOutBy && 
    userId &&
    (project.checkedOutBy.toString() === userId || project.checkedOutBy === userId);
  return (
    <article
      className="project-preview"
      role="article"
      aria-labelledby={`proj-${project._id}-title`}
      style={{
        border: isCheckedOutByCurrentUser ? '2px solid #28a745' : undefined,
        backgroundColor: isCheckedOutByCurrentUser ? '#f8fff8' : undefined
      }}
    >
      <h3 id={`proj-${project._id}-title`}>{project.name}</h3>
      <p>
        by <strong>{owner?.name || "Loading..."}</strong> · updated{" "}
        {formatDate(project.createdAt)}
      </p>
      <p>{project.description}</p>
      <div style={{ margin: '0.5rem 0' }}>
        {project.hashtags && project.hashtags.map((tag, index) => (
          <span 
            key={index} 
            style={{ 
              background: '#e0e7ff', 
              color: '#3730a3', 
              padding: '0.2rem 0.5rem', 
              borderRadius: '1rem', 
              fontSize: '0.8rem',
              marginRight: '0.5rem',
              display: 'inline-block'
            }}
          >
            {tag}
          </span>
        ))}
      </div>
      <footer style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '1rem' }}>
        <small>
          Members: {project.members?.length || 0} · Version: {project.version || 'N/A'}
          {project.checkedOut && <span style={{ color: 'orange' }}> · Checked Out</span>}
        </small>
        <div style={{ display: 'flex', gap: '0.7rem' }}>
          <button 
            className="project-btn project-btn-check"
            onClick={handleViewProject}
          >
            View Project
          </button>
          <button 
            className="project-btn project-btn-edit"
            onClick={handleEditProject}
          >
            Edit Project
          </button>
          {!project.checkedOut ? (
            <button
              className="project-btn project-btn-feed"
              onClick={handleCheckoutProject}
              disabled={loading}
            >
              {loading ? 'Checking out...' : 'Checkout'}
            </button>
          ) : isCheckedOutByCurrentUser ? (
            <button
              className="project-btn project-btn-feed"
              onClick={handleCheckinProject}
              disabled={loading}
              style={{ background: '#28a745' }}
            >
              {loading ? 'Checking in...' : 'Check In'}
            </button>
          ) : (
            <button
              className="project-btn project-btn-feed"
              disabled
              style={{ background: '#6c757d' }}
            >
              Checked Out
            </button>
          )}
        </div>
      </footer>
    </article>
  );
}