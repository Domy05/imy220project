import React, { useState } from "react";
import "../css/LoginForm.css";

export default function LoginForm({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  //these are the states

  const submit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:5000/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: 'include', // Include cookies for JWT
        body: JSON.stringify({ email, password }),
      });
      
      const data = await response.json();
      
      if (response.ok && data.user) {
        localStorage.setItem("user", JSON.stringify(data.user));
        localStorage.setItem("token", data.token);
        onLogin?.(data.user);
      } else {
        alert(data.message || "Login failed.");
      }
    } catch (err) {
      console.error('Login error:', err);
      alert("Network error. Please try again.");
    }
  };

  return (
    <div className="login-form-container">      {/*form for the signing up*/}
      <form className="login-form-card" onSubmit={submit} aria-label="Login">
        <fieldset>
          <legend>Login</legend>

          <label htmlFor="login-email">Email</label>
          <input
            id="login-email"
            type="email"
            value={email}
            placeholder="imy220@uniP.com"
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <label htmlFor="login-password">Password</label>
          <input
            id="login-password"
            type="password"
            value={password}
            placeholder="Enter password here"
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <button type="submit" className="login-btn">
            Sign in
          </button>
        </fieldset>
      </form>
    </div>
  );
}
