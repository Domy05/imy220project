import React, { useState, useEffect } from "react";
import { searchAPI } from "../utils/api";
import '../css/SearchInput.css';

export default function SearchInput({
  placeholder = "Search projects, users, or check-ins…",
  onChange,
  onResults
}) {
  const [value, setValue] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (value.trim()) {
        performSearch(value.trim());
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [value]);

  const performSearch = async (query) => {
    try {
      setLoading(true);
      const searchResults = await searchAPI.search(query);
      onResults?.(searchResults);
    } catch (err) {
      console.error('Search error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handle = (e) => {
    const v = e.target.value;
    setValue(v);
    onChange?.(v);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (value.trim()) {
      performSearch(value.trim());
    }
  };

  const totalResults = 0;
  return (
    <div className="search-input-container" style={{ position: 'relative' }}>
      <form role="search" onSubmit={handleSubmit} style={{ width: "100%" }}>
        <div style={{ position: 'relative' }}>
          <input
            id="search"
            type="search"
            value={value}
            onChange={handle}
            placeholder={placeholder}
            style={{ width: '100%', paddingRight: loading ? '40px' : '10px' }}
          />
          {loading && (
            <div style={{ 
              position: 'absolute', 
              right: '10px', 
              top: '50%', 
              transform: 'translateY(-50%)',
              fontSize: '0.8rem',
              color: '#666'
            }}>
              Searching...
            </div>
          )}
        </div>
      </form>
    </div>
  );
}