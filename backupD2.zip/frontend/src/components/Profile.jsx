import React, { useState, useEffect } from "react";
import { userAPI, projectAPI } from "../utils/api";
import "../css/Profile.css";

export default function Profile({ user, projects = [], isOwnProfile, onEdit }) {
  const [friends, setFriends] = useState([]);
  const [collaborations, setCollaborations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadFriendsAndCollaborations();
  }, [user]);

  const loadFriendsAndCollaborations = async () => {
    try {
      // Load friends
      if (user.friends && user.friends.length > 0) {
        const friendPromises = user.friends.map(friendId => 
          userAPI.getById(friendId).catch(err => ({ _id: friendId, name: 'Unknown User' }))
        );
        const friendData = await Promise.all(friendPromises);
        setFriends(friendData);
      }

      // Load collaborations using the new API endpoint
      try {
        const userProjects = await userAPI.getProjects(user._id || user.id);
        const userId = user._id || user.id;
        
        // Filter to get only collaborations (projects where user is member but not owner)
        const userCollaborations = userProjects.filter(project => {
          return project.members && project.members.includes(userId) && project.owner !== userId;
        });
        setCollaborations(userCollaborations);
      } catch (err) {
        console.error('Error loading collaborations:', err);
        // Fallback to the old method if new endpoint fails
        const allProjects = await projectAPI.getAll();
        const userId = user._id || user.id;
        const userCollaborations = allProjects.filter(project => {
          return project.members && project.members.includes(userId) && project.owner !== userId;
        });
        setCollaborations(userCollaborations);
      }
    } catch (err) {
      console.error('Error loading friends:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddFriend = async () => {
    try {
      const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
      await userAPI.addFriend(currentUser._id, user._id);
      // Reload friends list
      await loadFriendsAndCollaborations();
      alert('Friend added successfully!');
    } catch (err) {
      console.error('Error adding friend:', err);
      alert('Failed to add friend');
    }
  };

  const handleRemoveFriend = async (friendId) => {
    try {
      const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
      await userAPI.removeFriend(currentUser._id, friendId);
      await loadFriendsAndCollaborations();
      alert('Friend removed successfully!');
    } catch (err) {
      console.error('Error removing friend:', err);
      alert('Failed to remove friend');
    }
  };

  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
  const isFriend = friends.some(friend => friend._id === currentUser._id);
  const canAddFriend = !isOwnProfile && !isFriend;

  return (
    <div className="edit-profile-form-container">
      <div className="edit-profile-form-content">
        <div className="edit-profile-form-left">
          <div className="user-header" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: '1.5rem' }}>
            <img
              src={
                user.profilePicture 
                  ? (user.profilePicture.startsWith('http') 
                      ? user.profilePicture 
                      : `http://localhost:5000${user.profilePicture}`)
                  : user.avatarUrl 
                  ? user.avatarUrl
                  : `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name || 'User')}&background=random`
              }
              alt={`Avatar of ${user.name}`}
              width="96"
              height="96"
              style={{ borderRadius: "50%", marginBottom: "0.7rem", objectFit: "cover", boxShadow: "0 2px 8px rgba(20,40,80,0.10)" }}
            />
            <span className="username" style={{ fontSize: '1.5rem', fontWeight: 700, color: '#19325c', marginTop: '0.2rem' }}>
              {user.username}
            </span>
          </div>
          
          <div aria-label="Profile info">
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ fontWeight: 'bold', display: 'block', marginBottom: '0.5rem' }}>Name:</label>
              <span>{user.name}</span>
            </div>
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ fontWeight: 'bold', display: 'block', marginBottom: '0.5rem' }}>Email:</label>
              <span>{user.email}</span>
            </div>
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ fontWeight: 'bold', display: 'block', marginBottom: '0.5rem' }}>Bio:</label>
              <span>{user.bio || 'No bio provided'}</span>
            </div>
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ fontWeight: 'bold', display: 'block', marginBottom: '0.5rem' }}>Member since:</label>
              <span>{new Date(user.createdAt).toLocaleDateString()}</span>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '1rem', marginTop: '2rem' }}>
            {isOwnProfile && onEdit && (
              <button className="edit-btn" onClick={onEdit}>
                Edit Profile
              </button>
            )}
            {canAddFriend && (
              <button 
                onClick={handleAddFriend}
                style={{ background: '#28a745', color: 'white', border: 'none', padding: '0.5rem 1rem', borderRadius: '4px', cursor: 'pointer' }}
              >
                Add Friend
              </button>
            )}
          </div>
        </div>
        
        <div className="edit-profile-form-right">
          <div>
            <label style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <strong>Friends ({friends.length})</strong>
              {loading && <span style={{ fontSize: '0.8rem', color: '#666' }}>Loading...</span>}
            </label>
            <ul>
              {friends.length === 0 ? (
                <li>{isOwnProfile ? 'You have no friends yet.' : 'No friends to show.'}</li>
              ) : (
                friends.map((friend) => (
                  <li key={friend._id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span>{friend.name}</span>
                    {isOwnProfile && (
                      <button
                        onClick={() => handleRemoveFriend(friend._id)}
                        style={{ background: '#dc3545', color: 'white', border: 'none', borderRadius: '3px', padding: '2px 6px', cursor: 'pointer', fontSize: '0.8rem' }}
                      >
                        Remove
                      </button>
                    )}
                  </li>
                ))
              )}
            </ul>
          </div>
          
          <div style={{ marginTop: '2rem' }}>
            <label><strong>Collaborating On ({collaborations.length})</strong></label>
            <ul>
              {collaborations.length === 0 ? (
                <li>{isOwnProfile ? 'You are not collaborating on any projects.' : 'Not collaborating on any projects.'}</li>
              ) : (
                collaborations.map((project) => (
                  <li key={project._id}>
                    <a href={`/project/${project._id}`} style={{ color: '#007bff', textDecoration: 'none' }}>
                      {project.name}
                    </a>
                    <span style={{ fontSize: '0.8rem', color: '#666', marginLeft: '0.5rem' }}>
                      (as contributor)
                    </span>
                  </li>
                ))
              )}
            </ul>
          </div>
          
          <div style={{ marginTop: '2rem' }}>
            <label><strong>Projects ({projects.length})</strong></label>
            <ul>
              {projects.length === 0 ? (
                <li>{isOwnProfile ? 'No projects created yet.' : 'No projects to show.'}</li>
              ) : (
                projects.map((project) => (
                  <li key={project._id}>
                    <a href={`/project/${project._id}`} style={{ color: '#007bff', textDecoration: 'none' }}>
                      {project.name}
                    </a>
                    <span style={{ fontSize: '0.8rem', color: '#666', marginLeft: '0.5rem' }}>
                      v{project.version}
                    </span>
                  </li>
                ))
              )}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}