import React, { useState, useEffect } from "react";
import '../css/HeaderNav.css';
import { Link } from 'react-router-dom';    //used for the client side navigation

//EXPORT = MAKES THIS FUNCTION AVAILABLE TO OTHER OTHER FILES
export default function HeaderNav({ isLoggedIn, onLogout }) {
  const [theme, setTheme] = useState('light');
  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
  const currentUserId = currentUser._id || currentUser.id || currentUser.userId;

  useEffect(() => {
    document.body.classList.remove('theme-light', 'theme-dark');
    document.body.classList.add(`theme-${theme}`);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  const handleLogout = async () => {
    try {
      await fetch('http://localhost:5000/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
      });
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      // Clear local storage regardless of API call success
      localStorage.removeItem('user');
      localStorage.removeItem('token');
      onLogout();
    }
  };

  return (
    <header>
      <nav aria-label="Main" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'relative' }}>
        <ul style={{ display: 'flex', gap: '1rem', margin: 0, padding: 0 }}>
<li><Link to="/">Splash</Link></li>
<li><Link to="/home">Home</Link></li>
<li><Link to="/profile">Profile</Link></li>
<li><Link to="/projects">Projects</Link></li>
<li><Link to="/feed">Feed</Link></li>
        </ul>
        <button
          className="theme-toggle-btn"
          onClick={toggleTheme}   //toggles when clicked
          aria-label="Toggle light/dark mode"
          style={{
            marginLeft: 'auto',
            background: theme === 'dark' ? '#f4f6fb' : '#19325c',
            color: theme === 'dark' ? '#19325c' : '#fff',
            border: 'none',
            borderRadius: '20px',
            padding: '0.5rem 1.2rem',
            fontWeight: 600,
            fontSize: '1rem',
            cursor: 'pointer',
            boxShadow: '0 1px 4px rgba(20, 40, 80, 0.08)',
            transition: 'background 0.2s, color 0.2s',
          }}
        >
          {theme === 'light' ? 'Dark mode' : 'Light mode'}
        </button>
        {isLoggedIn && (
          <button
            onClick={handleLogout}
            style={{
              marginLeft: '1rem',
              background: '#c62828',
              color: '#fff',
              border: 'none',
              borderRadius: '20px',
              padding: '0.5rem 1.2rem',
              fontWeight: 600,
              fontSize: '1rem',
              cursor: 'pointer',
              boxShadow: '0 1px 4px rgba(20, 40, 80, 0.08)',
              transition: 'background 0.2s, color 0.2s',
              zIndex: 1000,
            }}
          >
            Logout
          </button>
        )}
      </nav>
    </header>
  );
}
