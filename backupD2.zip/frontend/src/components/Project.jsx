import React, { useState } from "react";
import { projectAPI } from "../utils/api";
import "../css/Project.css";

export default function Project({ project, onEdit, onProjectUpdate }) {
  const [loading, setLoading] = useState(false);

  // Defensive: handle missing project prop
  if (!project) {
    return (
      <div className="project-form-container">
        <div className="project-form-content">
          <div className="project-form-left">
            <fieldset>
              <legend>Project Info</legend>
              <p>No project data available.</p>
            </fieldset>
          </div>
        </div>
      </div>
    );
  }

  const handleCheckoutProject = async () => {
    try {
      setLoading(true);
      const result = await projectAPI.checkout(project._id);
      
      if (result.success) {
        alert(`Successfully checked out project: ${project.name}`);
        // Update the project state if callback provided
        if (onProjectUpdate) {
          onProjectUpdate(result.project);
        }
      }
    } catch (err) {
      console.error('Error checking out project:', err);
      
      // Handle specific error messages
      if (err.message.includes('403')) {
        alert('You do not have permission to checkout this project. You must be a project member.');
      } else if (err.message.includes('400')) {
        alert('This project is already checked out by someone else.');
      } else {
        alert('Failed to checkout project. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleCheckinProject = async () => {
    try {
      setLoading(true);
      const checkinData = {
        message: `Project checked in by ${currentUser.name || 'user'}`,
        version: project.version || '1.0.0'
      };
      
      const result = await projectAPI.checkin(project._id, checkinData);
      
      if (result.success) {
        alert(`Successfully checked in project: ${project.name}`);
        // Update the project state if callback provided
        if (onProjectUpdate) {
          // The project should now be available for checkout again
          const updatedProject = { ...project, checkedOut: false, checkedOutBy: null };
          onProjectUpdate(updatedProject);
        }
      }
    } catch (err) {
      console.error('Error checking in project:', err);
      alert('Failed to check in project. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Check if current user has this project checked out
  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
  
  // Try different possible user ID fields
  const userId = currentUser._id || currentUser.id || currentUser.userId;
  
  const isCheckedOutByCurrentUser = project.checkedOut && 
    project.checkedOutBy && 
    userId &&
    (project.checkedOutBy.toString() === userId || project.checkedOutBy === userId);

  // Read-only project info
  const [name] = useState(project.name || "Campus Notes");
  const [description] = useState(project.description || "Sharing lecture notes with versioning.");
  const [tags] = useState(
    Array.isArray(project.tags) ? project.tags.join(", ") : (project.tags || "react, express")
  );
  const [contributors] = useState(
    Array.isArray(project.contributors) ? project.contributors : ["james", "bird"]
  );
  const [files] = useState(
    Array.isArray(project.files)
      ? project.files
      : [
          { id: "f1", path: "file1.py", size: 1024 },
          { id: "f2", path: "file2.jsx", size: 2048 },
          { id: "f3", path: "server.js", size: 4096 },
        ]
  );

  return (
    <div className="project-form-container" style={{
      border: isCheckedOutByCurrentUser ? '3px solid #28a745' : undefined,
      backgroundColor: isCheckedOutByCurrentUser ? '#f8fff8' : undefined,
      borderRadius: isCheckedOutByCurrentUser ? '8px' : undefined
    }}>
      <div className="project-form-content">
        <div className="project-form-left">
          <fieldset>
            <legend>Project Info</legend>
            <label>
              Project Name
              <input
                value={name}
                readOnly
                placeholder="Your projects name"
              />
            </label>
            <label>
              Description
              <textarea
                value={description}
                readOnly
                placeholder="The projects description"
              />
            </label>
            <label>
              Tags (comma separated)
              <input
                value={tags}
                readOnly
                placeholder="e.g., java, delphi"
              />
            </label>
            <div style={{ marginTop: '10px' }}>
              {project.checkedOut && (
                <div style={{ 
                  width: '100%', 
                  padding: '8px', 
                  background: '#fff3cd', 
                  border: '1px solid #ffeaa7', 
                  borderRadius: '4px', 
                  marginBottom: '10px',
                  fontSize: '0.9rem',
                  color: '#856404'
                }}>
                  🔒 This project is currently checked out
                  {isCheckedOutByCurrentUser ? ' by you' : ' by another user'}
                </div>
              )}
              
              <div style={{ display: 'flex', gap: '12px' }}>
                <button
                  type="button"
                  style={{ 
                    flex: 1, 
                    padding: '12px 0', 
                    background: (project.checkedOut && !isCheckedOutByCurrentUser) ? '#6c757d' : '#1a237e', 
                    color: '#fff', 
                    border: 'none', 
                    borderRadius: '8px', 
                    fontSize: '1.1rem', 
                    fontWeight: 500, 
                    cursor: (project.checkedOut && !isCheckedOutByCurrentUser) ? 'not-allowed' : 'pointer', 
                    transition: 'background 0.2s' 
                  }}
                  onClick={onEdit}
                  disabled={project.checkedOut && !isCheckedOutByCurrentUser}
                >
                  Edit Project
                </button>
                
                {!project.checkedOut ? (
                  <button
                    type="button"
                    style={{ flex: 1, padding: '12px 0', background: '#3949ab', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '1.1rem', fontWeight: 500, cursor: 'pointer', transition: 'background 0.2s' }}
                    onClick={handleCheckoutProject}
                    disabled={loading}
                  >
                    {loading ? 'Checking out...' : 'Check Out Project'}
                  </button>
                ) : isCheckedOutByCurrentUser ? (
                  <button
                    type="button"
                    style={{ flex: 1, padding: '12px 0', background: '#28a745', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '1.1rem', fontWeight: 500, cursor: 'pointer', transition: 'background 0.2s' }}
                    onClick={handleCheckinProject}
                    disabled={loading}
                  >
                    {loading ? 'Checking in...' : 'Check In Project'}
                  </button>
                ) : (
                  <button
                    type="button"
                    style={{ flex: 1, padding: '12px 0', background: '#6c757d', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '1.1rem', fontWeight: 500, cursor: 'not-allowed' }}
                    disabled
                  >
                    Checked Out by Other User
                  </button>
                )}
              </div>
            </div>
          </fieldset>
        </div>
        <div className="project-form-right">
          <div style={{ marginBottom: "32px" }}>
            <label><strong>Contributors</strong></label>
            <ul>
              {contributors.length === 0 ? (
                <li>You currently have no contributors yet.</li>
              ) : (
                contributors.map((c, idx) => <li key={idx}>{c}</li>)    //list them all
              )}
            </ul>
          </div>
          <label><strong>Project Files</strong></label>
          <ul>
            {files.length === 0 ? (
              <li>You have no files yet.</li>
            ) : (
              files.map(file => (
                <li key={file.id}>{file.path} ({file.size} bytes)</li>      //same here
              ))
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}