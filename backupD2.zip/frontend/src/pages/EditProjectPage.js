import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import EditProjectForm from "../components/EditProjectForm";
import { projectAPI } from "../utils/api";

export default function EditProjectPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadProject();
  }, [id]);

  const loadProject = async () => {
    try {
      setLoading(true);
      const projectData = await projectAPI.getById(id);
      setProject(projectData);
      setError(null);
    } catch (err) {
      console.error('Error loading project:', err);
      setError('Failed to load project');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (updatedProject) => {
    try {
      await projectAPI.update(id, updatedProject);
      alert('Project updated successfully!');
      navigate(`/project/${id}`);
    } catch (err) {
      console.error('Error updating project:', err);
      alert('Failed to update project');
    }
  };

  const handleCancel = () => {
    navigate(`/project/${id}`);
  };

  if (loading) {
    return <div style={{ padding: '2rem', textAlign: 'center' }}>Loading project...</div>;
  }

  if (error) {
    return (
      <div style={{ padding: '2rem', textAlign: 'center' }}>
        <p>{error}</p>
        <button onClick={() => navigate('/home')}>Back to Home</button>
      </div>
    );
  }

  return (
    <main style={{ padding: '1rem' }}>
      <EditProjectForm 
        project={project} 
        onSave={handleSave}
        onCancel={handleCancel}
      />
    </main>
  );
}