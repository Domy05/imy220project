import React, { useState, useEffect } from 'react';
import HeaderNav from '../components/HeaderNav';
import ProjectPreview from '../components/ProjectPreview';
import CreateProjectForm from '../components/CreateProjectForm';
import { projectAPI } from '../utils/api';
import '../css/ProjectPage.css';

export default function ProjectPage() {
  const [showCreate, setShowCreate] = useState(false);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    try {
      setLoading(true);
      const data = await projectAPI.getAll();
      setProjects(data);
      setError(null);
    } catch (err) {
      console.error('Error loading projects:', err);
      setError('Failed to load projects');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateProject = async (projectData) => {
    try {
      await projectAPI.create(projectData);
      await loadProjects(); // Reload projects
      setShowCreate(false);
    } catch (err) {
      console.error('Error creating project:', err);
      alert('Failed to create project');
    }
  };

  const handleProjectUpdate = (updatedProject) => {
    // Update the project in the local state
    setProjects(prevProjects => 
      prevProjects.map(p => 
        p._id === updatedProject._id ? updatedProject : p
      )
    );
  };

  if (loading) {
    return (
      <>
        <HeaderNav />
        <main className="projectpage-main">
          <p>Loading projects...</p>
        </main>
      </>
    );
  }

  if (error) {
    return (
      <>
        <HeaderNav />
        <main className="projectpage-main">
          <p>{error}</p>
        </main>
      </>
    );
  }

  return (
    <>
      <HeaderNav />
      <main className="projectpage-main">
        <div className="projectpage-btn-row">
          <button
            className="projectpage-btn projectpage-btn-create"
            onClick={() => setShowCreate(true)}
          >
            Create New Project
          </button>
        </div>
        {showCreate ? (
          <CreateProjectForm 
            onCreate={handleCreateProject}
            onCancel={() => setShowCreate(false)}
          />
        ) : (
          <section>
            {projects.length === 0 ? (
              <p>No projects found.</p>
            ) : (
              projects.map(project => (
                <ProjectPreview 
                  key={project._id} 
                  project={project} 
                  onProjectUpdate={handleProjectUpdate}
                />
              ))
            )}
          </section>
        )}
      </main>
    </>
  );
}