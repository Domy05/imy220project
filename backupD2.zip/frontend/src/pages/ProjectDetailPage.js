import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import HeaderNav from '../components/HeaderNav';
import { projectAPI, userAPI } from '../utils/api';
import '../css/ProjectDetailPage.css';

export default function ProjectDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [owner, setOwner] = useState(null);
  const [contributors, setContributors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    loadProjectDetails();
  }, [id]);

  const loadProjectDetails = async () => {
    try {
      setLoading(true);
      const projectData = await projectAPI.getById(id);
      setProject(projectData);

      // Load owner data
      if (projectData.owner) {
        const ownerData = await userAPI.getById(projectData.owner);
        setOwner(ownerData);
      }

      // Load contributors data
      if (projectData.contributors && projectData.contributors.length > 0) {
        const contributorPromises = projectData.contributors.map(contributorId => 
          userAPI.getById(contributorId)
        );
        const contributorData = await Promise.all(contributorPromises);
        setContributors(contributorData);
      }

      setError(null);
    } catch (err) {
      console.error('Error loading project details:', err);
      setError('Failed to load project details');
    } finally {
      setLoading(false);
    }
  };

  const handleCheckout = async () => {
    try {
      setActionLoading(true);
      const result = await projectAPI.checkout(project._id);
      
      if (result.success) {
        alert(`Successfully checked out project: ${project.name}`);
        await loadProjectDetails(); // Reload to update checkout status
      } else {
        alert(result.message || 'Failed to checkout project');
      }
    } catch (err) {
      console.error('Error during checkout:', err);
      alert('Failed to checkout project');
    } finally {
      setActionLoading(false);
    }
  };

  const handleCheckin = async () => {
    try {
      setActionLoading(true);
      const result = await projectAPI.checkin(project._id);
      
      if (result.success) {
        alert(`Successfully checked in project: ${project.name}`);
        await loadProjectDetails(); // Reload to update checkout status
      } else {
        alert(result.message || 'Failed to checkin project');
      }
    } catch (err) {
      console.error('Error during checkin:', err);
      alert('Failed to checkin project');
    } finally {
      setActionLoading(false);
    }
  };

  const handleCancelCheckout = async () => {
    try {
      setActionLoading(true);
      const result = await projectAPI.cancelCheckout(project._id);
      
      if (result.success) {
        alert(`Cancelled checkout for project: ${project.name}`);
        await loadProjectDetails(); // Reload to update checkout status
      } else {
        alert(result.message || 'Failed to cancel checkout');
      }
    } catch (err) {
      console.error('Error cancelling checkout:', err);
      alert('Failed to cancel checkout');
    } finally {
      setActionLoading(false);
    }
  };

  const handleEdit = () => {
    navigate(`/project/${project._id}/edit`);
  };

  const formatDate = (dateString) => {
    try {
      return new Date(dateString).toLocaleDateString();
    } catch {
      return dateString;
    }
  };

  if (loading) {
    return (
      <>
        <HeaderNav />
        <main className="project-detail-main">
          <p>Loading project...</p>
        </main>
      </>
    );
  }

  if (error) {
    return (
      <>
        <HeaderNav />
        <main className="project-detail-main">
          <p>{error}</p>
          <button onClick={() => navigate('/projects')}>Back to Projects</button>
        </main>
      </>
    );
  }

  if (!project) {
    return (
      <>
        <HeaderNav />
        <main className="project-detail-main">
          <p>Project not found</p>
          <button onClick={() => navigate('/projects')}>Back to Projects</button>
        </main>
      </>
    );
  }

  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
  const currentUserId = currentUser._id;
  const isOwner = project.owner === currentUserId;
  const isContributor = project.contributors && project.contributors.includes(currentUserId);
  const canEdit = isOwner || isContributor;

  // Determine checkout status and available actions
  const isCheckedOut = project.checkedOutBy && project.checkedOutAt;
  const isCheckedOutByCurrentUser = isCheckedOut && project.checkedOutBy === currentUserId;
  const isCheckedOutByOther = isCheckedOut && project.checkedOutBy !== currentUserId;

  return (
    <>
      <HeaderNav />
      <main className="project-detail-main">
        <div className="project-detail-header">
          <button 
            className="back-button"
            onClick={() => navigate('/projects')}
          >
            ← Back to Projects
          </button>
        </div>

        <div className="project-detail-content">
          <div className="project-info">
            <h1>{project.name}</h1>
            <p className="project-description">{project.description}</p>
            
            <div className="project-meta">
              <div className="meta-item">
                <strong>Owner:</strong> {owner ? owner.username : 'Loading...'}
              </div>
              <div className="meta-item">
                <strong>Created:</strong> {formatDate(project.createdAt)}
              </div>
              <div className="meta-item">
                <strong>Last Modified:</strong> {formatDate(project.updatedAt)}
              </div>
              {project.hashtags && project.hashtags.length > 0 && (
                <div className="meta-item">
                  <strong>Tags:</strong>
                  <div className="hashtags">
                    {project.hashtags.map((tag, index) => (
                      <span key={index} className="hashtag">#{tag}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {contributors.length > 0 && (
              <div className="contributors-section">
                <h3>Contributors</h3>
                <ul className="contributors-list">
                  {contributors.map((contributor, index) => (
                    <li key={index}>{contributor.username}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div className="version-control-section">
            <h2>Version Control</h2>
            
            <div className="checkout-status">
              {!isCheckedOut && (
                <div className="status-available">
                  <p>✅ Project is available for checkout</p>
                </div>
              )}
              
              {isCheckedOutByCurrentUser && (
                <div className="status-checked-out-by-user">
                  <p>🔒 You have this project checked out</p>
                  <p className="checkout-time">Since: {formatDate(project.checkedOutAt)}</p>
                </div>
              )}
              
              {isCheckedOutByOther && (
                <div className="status-checked-out-by-other">
                  <p>⚠️ Project is currently checked out by another user</p>
                  <p className="checkout-time">Since: {formatDate(project.checkedOutAt)}</p>
                </div>
              )}
            </div>

            <div className="action-buttons">
              {!isCheckedOut && canEdit && (
                <button
                  className="btn btn-primary"
                  onClick={handleCheckout}
                  disabled={actionLoading}
                >
                  {actionLoading ? 'Checking out...' : 'Checkout Project'}
                </button>
              )}

              {isCheckedOutByCurrentUser && (
                <>
                  <button
                    className="btn btn-success"
                    onClick={handleCheckin}
                    disabled={actionLoading}
                  >
                    {actionLoading ? 'Checking in...' : 'Check In Changes'}
                  </button>
                  <button
                    className="btn btn-secondary"
                    onClick={handleCancelCheckout}
                    disabled={actionLoading}
                  >
                    {actionLoading ? 'Cancelling...' : 'Cancel Checkout'}
                  </button>
                  <button
                    className="btn btn-edit"
                    onClick={handleEdit}
                  >
                    Edit Project
                  </button>
                </>
              )}

              {isCheckedOutByOther && (
                <p className="checkout-message">
                  You cannot modify this project while it's checked out by another user.
                </p>
              )}

              {!canEdit && (
                <p className="permission-message">
                  You don't have permission to modify this project.
                </p>
              )}
            </div>
          </div>

          {project.projectFile && (
            <div className="project-files-section">
              <h3>Project Files</h3>
              <div className="file-item">
                <a 
                  href={`http://localhost:5000/uploads/${project.projectFile}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="file-link"
                >
                  📁 {project.projectFile}
                </a>
              </div>
            </div>
          )}
        </div>
      </main>
    </>
  );
}