import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import HeaderNav from '../components/HeaderNav';
import Project from '../components/Project';
import EditProjectForm from '../components/EditProjectForm';
import ProjectFeed from '../components/ProjectFeed';
import { projectAPI } from '../utils/api';

export default function ProjectViewPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    loadProject();
  }, [id]);

  const loadProject = async () => {
    try {
      setLoading(true);
      const data = await projectAPI.getById(id);
      setProject(data);
      setError(null);
    } catch (err) {
      console.error('Error loading project:', err);
      setError('Failed to load project');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleSaveEdit = async (updatedProject) => {
    try {
      const saved = await projectAPI.update(id, updatedProject);
      setProject(saved);
      setIsEditing(false);
    } catch (err) {
      console.error('Error updating project:', err);
      alert('Failed to update project');
    }
  };

  const handleProjectUpdate = (updatedProject) => {
    setProject(updatedProject);
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
  };

  if (loading) {
    return (
      <>
        <HeaderNav />
        <main style={{ padding: '20px' }}>
          <p>Loading project...</p>
        </main>
      </>
    );
  }

  if (error || !project) {
    return (
      <>
        <HeaderNav />
        <main style={{ padding: '20px' }}>
          <p>{error || 'Project not found'}</p>
          <button onClick={() => navigate('/projects')}>Back to Projects</button>
        </main>
      </>
    );
  }

  return (
    <>
      <HeaderNav />
      <main style={{ padding: '20px' }}>
        <div style={{ marginBottom: '20px' }}>
          <button onClick={() => navigate('/projects')}>← Back to Projects</button>
        </div>
        {isEditing ? (
          <EditProjectForm 
            project={project}
            onSave={handleSaveEdit}
            onCancel={handleCancelEdit}
          />
        ) : (
          <>
            <Project 
              project={project} 
              onEdit={handleEdit}
              onProjectUpdate={handleProjectUpdate}
            />
            <ProjectFeed projectId={id} />
          </>
        )}
      </main>
    </>
  );
}