import React, { useEffect, useState } from "react";
import "../css/SplashPage.css";
 import SignUpForm from "../components/SignUpForm";
 import LoginForm from "../components/LoginForm";

export default function SplashPage() {
  const [form, setForm] = useState(null); // 'login' or 'signup'
  
  useEffect(() => {
    const handleScroll = () => {
      document.querySelectorAll(".splash-card").forEach((card) => {
        const rect = card.getBoundingClientRect();
        if (rect.top < window.innerHeight - 60) {
          card.classList.add("splash-visible");
        }
      });
    };
    window.addEventListener("scroll", handleScroll);
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  if (form === "login") {
    return (
      <main className="splash-main" style={{ position: 'relative' }}>
        <LoginForm />
        <button
          style={{ position: 'fixed', bottom: '32px', right: '32px', zIndex: 1000, padding: '0.7rem 1.4rem', fontSize: '1rem', borderRadius: '8px', background: '#19325c', color: '#fff', border: 'none', boxShadow: '0 2px 8px rgba(20,40,80,0.10)', cursor: 'pointer' }}
          onClick={() => setForm(null)}
        >
          Back
        </button>
      </main>
    );
  }
  if (form === "signup") {
    return (
      <main className="splash-main" style={{ position: 'relative' }}>
        <SignUpForm />
        <button
          style={{ position: 'fixed', bottom: '32px', right: '32px', zIndex: 1000, padding: '0.7rem 1.4rem', fontSize: '1rem', borderRadius: '8px', background: '#19325c', color: '#fff', border: 'none', boxShadow: '0 2px 8px rgba(20,40,80,0.10)', cursor: 'pointer' }}
          onClick={() => setForm(null)}
        >
          Back
        </button>
      </main>
    );
  }
  return (
    <main className="splash-main">
      <div className="splash-welcome">
        <img
          src="/assests/images/MementoLogo.png"
          alt="Memento Logo"
          style={{ width: "220px", marginBottom: "1.2rem" }}
        />
        <h1 className="splash-welcome-animate">Welcome to YOUR Version Control space</h1>
        <p className="splash-welcome-animate">Collaborate on projects, manage files, and track changes all in one place.</p>
      </div>

      <div className="splash-btn-row">
        <button
          className="splash-btn splash-login-btn"
          onClick={() => setForm("login")}
        >
          Login
        </button>
        <button
          className="splash-btn splash-signup-btn"
          onClick={() => setForm("signup")}
        >
          Sign Up
        </button>
      </div>

      <div className="splash-down-arrow">
        <svg
          width="48"
          height="48"
          viewBox="0 0 48 48"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow
              dx="0"
              dy="0"
              stdDeviation="6"
              floodColor="#19325c"
            />
          </filter>
          <path
            d="M24 12v24M24 36l-10-10M24 36l10-10"
            stroke="#19325c"
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
            filter="url(#glow)"
          />
        </svg>
      </div>

      <section className="splash-cards">
        <div className="splash-card">
          <h2>About</h2>
          <p>
            This platform is a code focused version control website made to help
            devs and teams collaborate on shared projects. Users can create,
            edit and manage projects, check files in and out, and keep track of
            changes with activity feeds. It's got built in features for project
            discussions, user connections, and smooth file sharing. Whether you
            are coding solo or with friends, this is your space to build,
            version and share!
          </p>
        </div>
        <div className="splash-card">
          <h2>Why version control matters?</h2>
          <p>
            Programming without version control is like writing an essay and
            never hitting save—one wrong move and it's gone. Version control
            makes sure to keep your work safe, organized and trackable. It lets
            you experiment, collaborate, and fix mistakes without starting over.
            It's not just helpful, it's extremely essential!
          </p>
        </div>
        <div className="splash-card">
          <h2>Why use this platform?</h2>
          <p>
            Unlike other version control platforms, this site is built with
            simplicity and community in mind. It's got a clean vibe, an easy to
            use interface and all the features you actually care about. Plus,
            you can connect with other devs, show off your projects, and manage
            your work visually—not just through commit logs. It's all about you,
            your code, and a space that gets it.
          </p>
          <h3>Feature highlights</h3>
          <ul>
            <li>Check in/check out system</li>
            <li>Project management</li>
            <li>Activity feed</li>
            <li>User profiles and connections</li>
            <li>Smart search</li>
            <li>Project discussions</li>
            <li>Custom visual theme</li>
          </ul>
        </div>
      </section>
    </main>
  );
}