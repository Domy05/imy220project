
import React, { useState, useEffect } from 'react';
import FeedList from '../components/FeedList';
import HeaderNav from '../components/HeaderNav.jsx';
import { projectAPI, checkinAPI, userAPI } from '../utils/api';

export default function FeedPage() {
  const [projects, setProjects] = useState([]);
  const [checkins, setCheckins] = useState([]);
  const [filteredCheckins, setFilteredCheckins] = useState([]);
  const [filterProjectId, setFilterProjectId] = useState('global');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    // Filter checkins based on selected project
    if (filterProjectId === 'global') {
      setFilteredCheckins(checkins);
    } else {
      setFilteredCheckins(checkins.filter(checkin => 
        checkin.projectId === filterProjectId || 
        checkin.project === filterProjectId ||
        (typeof checkin.project === 'object' && checkin.project._id === filterProjectId) ||
        (typeof checkin.project === 'object' && checkin.project.toString() === filterProjectId)
      ));
    }
  }, [filterProjectId, checkins]);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Load projects and checkins in parallel
      const [projectsData, checkinsData] = await Promise.all([
        projectAPI.getAll(),
        checkinAPI.getAll()
      ]);
      
      setProjects(projectsData || []);
      setCheckins(checkinsData || []);
      setError(null);
    } catch (err) {
      console.error('Error loading feed data:', err);
      setError('Failed to load feed data');
    } finally {
      setLoading(false);
    }
  };

  // Get current user ID (you might need to adjust this based on your auth system)
  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
  const currentUserId = currentUser._id || currentUser.id || currentUser.userId;

  // Filter projects to show only those the user is involved in
  const userProjects = projects.filter(project => {
    const projectOwnerId = typeof project.owner === 'object' ? project.owner._id || project.owner.toString() : project.owner;
    const projectMembers = project.members || project.contributors || [];
    
    return projectOwnerId === currentUserId || 
           projectMembers.includes(currentUserId) ||
           projectMembers.some(member => 
             (typeof member === 'object' ? member._id || member.toString() : member) === currentUserId
           );
  });

  if (loading) {
    return (
      <>
        <HeaderNav isLoggedIn={true} onLogout={() => window.location.href = '#/'} />
        <main style={{ padding: '2rem' }}>
          <p>Loading feed...</p>
        </main>
      </>
    );
  }

  if (error) {
    return (
      <>
        <HeaderNav isLoggedIn={true} onLogout={() => window.location.href = '#/'} />
        <main style={{ padding: '2rem' }}>
          <p>{error}</p>
          <button onClick={loadData}>Retry</button>
        </main>
      </>
    );
  }

  return (
    <>
      <HeaderNav isLoggedIn={true} onLogout={() => window.location.href = '#/'} />
      <main style={{ padding: '2rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', marginBottom: '2rem', flexWrap: 'wrap' }}>
          <button
            onClick={() => setFilterProjectId('global')}
            style={{
              padding: '0.7rem 1.5rem',
              fontSize: '1rem',
              fontWeight: 600,
              borderRadius: '20px',
              border: 'none',
              background: filterProjectId === 'global' ? '#19325c' : '#f4f6fb',
              color: filterProjectId === 'global' ? '#fff' : '#19325c',
              boxShadow: '0 1px 4px rgba(20, 40, 80, 0.08)',
              cursor: 'pointer',
              transition: 'background 0.2s, color 0.2s',
            }}
          >
            Global Feed ({checkins.length})
          </button>
          
          {userProjects.length > 0 && (
            <div style={{ position: 'relative' }}>
              <label htmlFor="local-feed" style={{ fontWeight: 600, marginRight: '0.5rem', color: '#19325c' }}>
                Filter by Project:
              </label>
              <select
                id="local-feed"
                value={filterProjectId === 'global' ? '' : filterProjectId}
                onChange={e => setFilterProjectId(e.target.value || 'global')}
                style={{
                  padding: '0.7rem 1.5rem',
                  fontSize: '1rem',
                  borderRadius: '20px',
                  border: '1px solid #19325c',
                  background: filterProjectId !== 'global' ? '#19325c' : '#f4f6fb',
                  color: filterProjectId !== 'global' ? '#fff' : '#19325c',
                  fontWeight: 600,
                  cursor: 'pointer',
                  minWidth: '200px',
                }}
              >
                <option value="">Choose a project...</option>
                {userProjects.map(project => (
                  <option key={project._id} value={project._id}>
                    {project.name} 
                    {filterProjectId === project._id ? ` (${filteredCheckins.length})` : ''}
                  </option>
                ))}
              </select>
            </div>
          )}
          
          {userProjects.length === 0 && (
            <p style={{ 
              color: '#666', 
              fontStyle: 'italic',
              margin: 0,
              background: '#f8f9fa',
              padding: '0.5rem 1rem',
              borderRadius: '10px',
              fontSize: '0.9rem'
            }}>
              You don't have any projects yet. Create or join a project to see project-specific feeds!
            </p>
          )}
        </div>
        
        {filterProjectId !== 'global' && (
          <div style={{ 
            marginBottom: '1rem', 
            padding: '0.8rem 1.2rem', 
            background: '#e8f4f8', 
            border: '1px solid #19325c', 
            borderRadius: '10px',
            color: '#19325c'
          }}>
            <strong>Showing activity for:</strong> {userProjects.find(p => p._id === filterProjectId)?.name || 'Selected Project'} 
            ({filteredCheckins.length} {filteredCheckins.length === 1 ? 'entry' : 'entries'})
          </div>
        )}
        <FeedList messages={filteredCheckins} />
      </main>
    </>
  );
}