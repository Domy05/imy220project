import React, { useState, useEffect } from "react";
import ProjectPreview from "../components/ProjectPreview";
import SearchInput from "../components/SearchInput";
import CreateProjectForm from "../components/CreateProjectForm";
import { projectAPI } from "../utils/api";
import "../css/HomePage.css";

export default function HomePage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("lastModified");
  const [showCreate, setShowCreate] = useState(false);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    try {
      setLoading(true);
      const data = await projectAPI.getAll();
      setProjects(data);
      setError(null);
    } catch (err) {
      console.error('Error loading projects:', err);
      setError('Failed to load projects');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateProject = async (projectData) => {
    try {
      await projectAPI.create(projectData);
      await loadProjects(); // Reload projects
      setShowCreate(false);
    } catch (err) {
      console.error('Error creating project:', err);
      alert('Failed to create project');
    }
  };

  const handleProjectUpdate = (updatedProject) => {
    // Update the project in the local state
    setProjects(prevProjects => 
      prevProjects.map(p => 
        p._id === updatedProject._id ? updatedProject : p
      )
    );
  };

  const filteredProjects = projects.filter((p) =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.hashtags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Sort projects
  const sortedProjects = [...filteredProjects].sort((a, b) => {
    if (sortBy === "lastModified") {
      return new Date(b.createdAt) - new Date(a.createdAt);
    } else if (sortBy === "myProjects") {
      const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
      const currentUserId = currentUser._id;
      
      //sorts by the users projs first
      const aIsOwner = a.owner === currentUserId;
      const bIsOwner = b.owner === currentUserId;
      
      if (aIsOwner && !bIsOwner) return -1;
      if (!aIsOwner && bIsOwner) return 1;
      
      //if both are owners or both are not, sort by last modified
      return new Date(b.createdAt) - new Date(a.createdAt);
    } else if (sortBy === "alphabetical") {
      return a.name.toLowerCase().localeCompare(b.name.toLowerCase());
    }
    return 0;
  });

  if (loading) {
    return <div className="home-main"><p>Loading projects...</p></div>;
  }
  if (error) {
    return <div className="home-main"><p>{error}</p></div>;
  }

  return (
    <main className="home-main">
      {showCreate ? (
        <CreateProjectForm
          onCreate={handleCreateProject}
          onCancel={() => setShowCreate(false)}
        />
      ) : (
        <>
          <div className="home-search-bar">
            <SearchInput
              placeholder="Search projects..."
              onChange={setSearchTerm}
              showResults={true}
            />
          </div>
          <div className="home-row">
            <button className="home-btn">All Projects</button>
            <button
              className="home-btn home-btn-new"
              onClick={() => setShowCreate(true)}
            >
              New Project
            </button>
            <div className="home-sort">
              <label htmlFor="sortBy">Sort by:</label>
              <select
                id="sortBy"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
              >
                <option value="lastModified">Last Modified</option>
                <option value="myProjects">My Projects First</option>
                <option value="alphabetical">Alphabetical</option>
              </select>
            </div>
          </div>
          <section className="home-feed" aria-label="Project Feed">
            {sortedProjects.length > 0 ? (
              sortedProjects.map((project) => (
                <ProjectPreview 
                  key={project._id} 
                  project={project} 
                  onProjectUpdate={handleProjectUpdate}
                />
              ))
            ) : (
              <p>No projects found.</p>
            )}
          </section>
        </>
      )}
    </main>
  );
}
