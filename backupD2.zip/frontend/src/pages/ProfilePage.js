import React, { useState, useEffect } from "react";
import Profile from '../components/Profile';
import EditProfileForm from "../components/EditProfileForm";
import { userAPI, projectAPI } from "../utils/api";
import { useParams } from 'react-router-dom';
import "../css/ProfilePage.css";

export default function ProfilePage() {
    const { id } = useParams();
    const [user, setUser] = useState(null);
    const [userProjects, setUserProjects] = useState([]);
    const [showEdit, setShowEdit] = useState(false);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    
    const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
    const currentUserId = currentUser._id || currentUser.id || currentUser.userId;
    const isOwnProfile = !id || id === currentUserId || id === 'me';

    useEffect(() => {
        loadUserData();
    }, [id]);

    const loadUserData = async () => {
        try {
            setLoading(true);
            
            // Determine which user ID to use
            let userId;
            if (!id || isOwnProfile || id === 'me') {
                userId = currentUserId;
            } else {
                userId = id;
            }
            
            // Check if we have a valid user ID
            if (!userId) {
                throw new Error('No user ID available. Please log in again.');
            }
            
            console.log('Loading user data for ID:', userId);
            
            // Load user data
            const userData = await userAPI.getById(userId);
            setUser(userData);
            
            // Load user's projects
            const allProjects = await projectAPI.getAll();
            const userOwnedProjects = allProjects.filter(p => p.owner === userId);
            setUserProjects(userOwnedProjects);
            
            setError(null);
        } catch (err) {
            console.error('Error loading user data:', err);
            setError(err.message || 'Failed to load user profile');
        } finally {
            setLoading(false);
        }
    };

    const handleSaveProfile = async (updatedData) => {
        try {
            console.log('ProfilePage handleSaveProfile - received data:', updatedData);
            console.log('Is FormData:', updatedData instanceof FormData);
            
            await userAPI.update(user._id, updatedData);
            await loadUserData(); // Reload data
            setShowEdit(false);
        } catch (err) {
            console.error('Error updating profile:', err);
            alert('Failed to update profile');
        }
    };

    const handleDeleteProfile = async () => {
        if (window.confirm('Are you sure you want to delete your profile? This action cannot be undone.')) {
            try {
                await userAPI.delete(user._id);
                localStorage.removeItem('user');
                localStorage.removeItem('token');
                window.location.href = '/';
            } catch (err) {
                console.error('Error deleting profile:', err);
                alert('Failed to delete profile');
            }
        }
    };

    if (loading) return <div style={{ padding: '2rem' }}>Loading profile...</div>;
    if (error) return <div style={{ padding: '2rem' }}>{error}</div>;
    if (!user) return <div style={{ padding: '2rem' }}>User not found</div>;
    return (
        <main style={{ padding: '2rem' }}>
            {showEdit ? (
                <EditProfileForm 
                    user={user} 
                    onCancel={() => setShowEdit(false)} 
                    onSave={handleSaveProfile}
                    onDelete={isOwnProfile ? handleDeleteProfile : null}
                />
            ) : (
                <Profile 
                    user={user} 
                    projects={userProjects}
                    isOwnProfile={isOwnProfile}
                    onEdit={isOwnProfile ? () => setShowEdit(true) : null}
                />
            )}
        </main>
    );
}