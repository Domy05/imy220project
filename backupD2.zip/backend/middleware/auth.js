const jwt = require('jsonwebtoken');        //imporst json web token library. 
const { ObjectId } = require('../database');        //gets object id from database.js

module.exports = function(req, res, next) {
  const token = req.cookies?.token || (req.header('Authorization') || '').replace('Bearer ', '');   //looks for the token in cookies or auth header
  if (!token) {
    return res.status(401).json({ error: 'Theres no token, unauthorized' });
  }     //checks if token is found
  
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);      //checks to see that the token is legit
    //payload.id is the user id that was stored when the token was created
    req.userId = payload.id;    //gets and stores user id
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Token invalid' });
  }
};