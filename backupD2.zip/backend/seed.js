require('dotenv').config();
const { MongoClient, ObjectId } = require('mongodb');

const connectionString = process.env.MONGO_URI;

async function seedDatabase() {
  try {
    console.log('Starting database seeding...');
    
    // Connect to MongoDB
    const client = new MongoClient(connectionString, {
      useUnifiedTopology: true,
    });
    
    await client.connect();
    console.log('Connected to MongoDB');
    
    const database = client.db('imy220db');
    
    // Clear existing data
    await database.collection('users').deleteMany({});
    await database.collection('projects').deleteMany({});
    await database.collection('checkins').deleteMany({});
    console.log('Cleared existing data');

    // Create Users (minimum 2 required)
    const users = [
      {
        _id: new ObjectId(),
        username: 'alice',
        name: 'Alice Student',
        email: 'alice@test.com',
        password: 'password1',
        bio: 'Computer Science student passionate about web development',
        profileImage: '',
        friends: [],
        createdAt: new Date(),
        role: 'user'
      },
      {
        _id: new ObjectId(),
        username: 'bob',
        name: 'Bob Developer',
        email: 'bob@test.com',
        password: 'password2',
        bio: 'Full-stack developer with 3 years experience',
        profileImage: '',
        friends: [],
        createdAt: new Date(),
        role: 'user'
      },
      {
        _id: new ObjectId(),
        username: 'charlie',
        name: 'Charlie Designer',
        email: 'charlie@test.com',
        password: 'password3',
        bio: 'UI/UX designer who loves clean interfaces',
        profileImage: '',
        friends: [],
        createdAt: new Date(),
        role: 'user'
      },
      {
        _id: new ObjectId(),
        username: 'testuser',
        name: 'Test User',
        email: 'test@test.com',
        password: 'test1234',
        bio: 'Test account for development and marking',
        profileImage: '',
        friends: [],
        createdAt: new Date(),
        role: 'user'
      }
    ];

    // Insert users
    await database.collection('users').insertMany(users);
    console.log('Created users');

    // Get user references
    const alice = users[0];
    const bob = users[1];
    const charlie = users[2];
    const testUser = users[3];

    // Create Projects (minimum 2 required)
    const projects = [
      {
        _id: new ObjectId(),
        name: 'Memento - Social Media Platform',
        description: 'A social media platform for sharing and discovering creative projects',
        image: '',
        type: 'web',
        hashtags: ['#javascript', '#react', '#mongodb', '#social'],
        owner: alice._id,
        members: [alice._id, bob._id],
        version: '1.0.0',
        files: [],
        checkedOut: false,
        checkedOutBy: null,
        createdAt: new Date()
      },
      {
        _id: new ObjectId(),
        name: 'Weather Dashboard',
        description: 'A responsive weather application with location-based forecasts',
        image: '',
        type: 'mobile',
        hashtags: ['#javascript', '#weather', '#api', '#responsive'],
        owner: bob._id,
        members: [bob._id, charlie._id],
        version: '1.2.0',
        files: [],
        checkedOut: false,
        checkedOutBy: null,
        createdAt: new Date()
      },
      {
        _id: new ObjectId(),
        name: 'Portfolio Website',
        description: 'Personal portfolio showcasing design work and projects',
        image: '',
        type: 'web',
        hashtags: ['#portfolio', '#design', '#css', '#html'],
        owner: charlie._id,
        members: [charlie._id],
        version: '2.0.0',
        files: [],
        checkedOut: false,
        checkedOutBy: null,
        createdAt: new Date()
      },
      {
        _id: new ObjectId(),
        name: 'Task Manager',
        description: 'Simple task management app with drag and drop functionality',
        image: '',
        type: 'web',
        hashtags: ['#productivity', '#javascript', '#draganddrop'],
        owner: testUser._id,
        members: [testUser._id, alice._id],
        version: '1.0.0',
        files: [],
        checkedOut: false,
        checkedOutBy: null,
        createdAt: new Date()
      }
    ];

    // Insert projects
    await database.collection('projects').insertMany(projects);
    console.log('Created projects');

    // Create Check-ins (minimum 2 required)
    const checkins = [
      {
        _id: new ObjectId(),
        projectId: projects[0]._id,
        userId: alice._id,
        message: 'Initial project setup and authentication system',
        files: [],
        version: '1.0.0',
        createdAt: new Date()
      },
      {
        _id: new ObjectId(),
        projectId: projects[0]._id,
        userId: bob._id,
        message: 'Added user profile management and friend system',
        files: [],
        version: '1.0.0',
        createdAt: new Date()
      },
      {
        _id: new ObjectId(),
        projectId: projects[1]._id,
        userId: bob._id,
        message: 'Weather API integration and basic UI components',
        files: [],
        version: '1.0.0',
        createdAt: new Date()
      },
      {
        _id: new ObjectId(),
        projectId: projects[2]._id,
        userId: charlie._id,
        message: 'Portfolio design and responsive layout complete',
        files: [],
        version: '2.0.0',
        createdAt: new Date()
      }
    ];

    // Insert check-ins
    await database.collection('checkins').insertMany(checkins);
    console.log('Created checkins');

    // Create sample posts
    const posts = [
      {
        _id: new ObjectId(),
        project: projects[0]._id,
        user: alice._id,
        message: 'Just added the user authentication system! Now users can securely log in and manage their profiles.',
        type: 'post',
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000) // 2 hours ago
      },
      {
        _id: new ObjectId(),
        project: projects[1]._id,
        user: bob._id,
        message: 'Working on the restaurant data integration. Making good progress on the API endpoints.',
        type: 'update',
        createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000) // 4 hours ago
      },
      {
        _id: new ObjectId(),
        project: projects[0]._id,
        user: charlie._id,
        message: 'Love the new UI design! The color scheme really works well. Can\'t wait to see it live.',
        type: 'post',
        createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000) // 6 hours ago
      },
      {
        _id: new ObjectId(),
        project: projects[2]._id,
        user: testUser._id,
        message: 'Just deployed the latest version to staging. Everything looks good for tomorrow\'s demo!',
        type: 'update',
        createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000) // 1 hour ago
      }
    ];

    // Insert posts
    await database.collection('posts').insertMany(posts);
    console.log('Created posts');

    // Add friendships
    await database.collection('users').updateOne(
      { _id: alice._id },
      { $set: { friends: [bob._id, charlie._id] } }
    );
    await database.collection('users').updateOne(
      { _id: bob._id },
      { $set: { friends: [alice._id] } }
    );
    await database.collection('users').updateOne(
      { _id: charlie._id },
      { $set: { friends: [alice._id, testUser._id] } }
    );
    await database.collection('users').updateOne(
      { _id: testUser._id },
      { $set: { friends: [charlie._id] } }
    );
    console.log('Added friendships');

    console.log('\n========= SEED COMPLETED SUCCESSFULLY =========');
    console.log('Created:');
    console.log('- 4 users (alice, bob, charlie, testuser)');
    console.log('- 4 projects');
    console.log('- 4 checkins');
    console.log('- 4 posts');
    console.log('- Friend relationships established');
    console.log('=============================================\n');

    await client.close();
    console.log('Database connection closed');
    
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  }
}

// Run the seed function
seedDatabase();