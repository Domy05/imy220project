require('dotenv').config();         //loads the env file
const express = require('express');         //for webserver handling and http req/res
const { MongoClient } = require('mongodb');     //for connecting to mongo atlas
const cors = require('cors');       
const cookieParser = require('cookie-parser');
const path = require('path');


//importing all api route modules here. to attach to the express app
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const projectRoutes = require('./routes/projects');
const checkinRoutes = require('./routes/checkins');
const postsRoutes = require('./routes/posts');
const searchRoutes = require('./routes/search');

const app = express();      //creates express app instance

app.use(cors({ origin: true, credentials: true })); //allow all origins in dev
app.use(express.json());
app.use(cookieParser());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));   //serve files in uploads statically

//app is using the routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/checkins', checkinRoutes);
app.use('/api/posts', postsRoutes);
app.use('/api/search', searchRoutes);

app.post('/api/signup', (req, res) => {
    res.redirect(307, '/api/auth/register');
});

app.post('/api/signin', (req, res) => {
    res.redirect(307, '/api/auth/login');
});

app.use(express.static(path.join(__dirname, '../frontend/public')));

app.get('/api/health', (req, res) => res.send({ ok: true, time: new Date() }));

app.get('/', (req, res) => {
    res.json({ 
        message: 'IMY220 Backend API Server', 
        endpoints: {
            health: '/api/health',
            auth: '/api/auth',
            users: '/api/users',
            projects: '/api/projects',
            checkins: '/api/checkins',
            posts: '/api/posts',
            search: '/api/search'
        }
    });
});

const PORT = process.env.PORT || 5000;

const uri = process.env.MONGO_URI;
const client = new MongoClient(uri);

async function connectToMongoDB() {
    try {
        await client.connect();
        console.log('Connected to MongoDB');
        
        app.listen(PORT, () => {
            console.log(`Server running on port ${PORT}`);
            console.log(`Health check: http://localhost:${PORT}/api/health`);
        });
    } catch (err) {
        console.error('MongoDB connection error:', err.message);
        process.exit(1);
    }
}

// Start the server
connectToMongoDB();