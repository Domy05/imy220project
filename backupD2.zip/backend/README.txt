# IMY220 Project - Backend Setup and Usage Guide

## Prerequisites
- Node.js (v16 or higher)
- MongoDB Atlas account OR local MongoDB installation
- Postman or similar tool for API testing

## Quick Start

1. Install dependencies:
   npm install

2. Create .env file from .env.example:
   - Copy .env.example to .env
   - Fill in your MongoDB connection string
   - Set a secure JWT_SECRET

3. Seed the database:
   node seed.js

4. Start the development server:
   npm run dev

5. Server will be running on http://localhost:5000

## Environment Variables (.env file)
PORT=5000
MONGO_URI=mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/imy220db?retryWrites=true&w=majority
JWT_SECRET=your_long_random_secret_key_here
NODE_ENV=development

## Database Requirements Met
MongoDB database with appropriate collections
At least 2 user profiles
At least 2 projects  
At least 3 check-ins
Express.js backend in /backend folder
Working MongoDB connection

## API Endpoints

### Authentication
POST /api/auth/register - Create new account
POST /api/auth/login - Login user
POST /api/auth/logout - Logout user

### Users
GET /api/users - Get all users
GET /api/users/:id - Get user by ID
PUT /api/users/:id - Update user profile (auth required)
DELETE /api/users/:id - Delete user (auth required)

### Projects
GET /api/projects - Get all projects
POST /api/projects - Create project (auth required, supports file upload)
GET /api/projects/:id - Get project by ID
POST /api/projects/:id/checkout - Checkout project (auth required)
POST /api/projects/:id/checkin - Checkin project with files (auth required)

### Check-ins
GET /api/checkins - Get all check-ins
GET /api/checkins/project/:projectId - Get check-ins for project
GET /api/checkins/user/:userId - Get check-ins by user

### Search
GET /api/search?q=term - Search users, projects, and check-ins

## File Upload Support
- Maximum file size: 5MB
- Supported endpoints: project creation and check-ins
- Files stored in /backend/uploads/ directory

## Test User Credentials
Email: test@test.com
Password: test1234

Email: alice@test.com  
Password: password1

Email: bob@test.com
Password: password2

## Testing with curl/Postman

Register new user:
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"newuser","email":"new@test.com","password":"newpass","name":"New User"}'

Login:
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"test1234"}'

Get all projects:
curl http://localhost:5000/api/projects

## Important Notes for Marking
- Passwords are NOT hashed (as per specification for marking convenience)
- Connection string must be provided in submission
- All required data (2 users, 2 projects, 3 check-ins) created by seed.js
- Backend implements all required functionality for Part 1

## Troubleshooting
- Ensure MongoDB connection string is correct in .env
- Run seed.js if database is empty
- Check console for detailed error messages
- Verify all npm dependencies are installed


backend
npm run dev

frontend
npm start