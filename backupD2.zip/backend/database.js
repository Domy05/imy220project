const { MongoClient, ObjectId } = require("mongodb");

// Connection URI from .env
const uri = process.env.MONGO_URI;
const client = new MongoClient(uri);

// Database name
const dbName = 'imy220db';

// Flag to track connection status
let isConnected = false;

// Initialize connection
async function initializeConnection() {
    if (!isConnected) {
        await client.connect();
        isConnected = true;
        console.log('Database connection established');
    }
}

// Generic function to run find queries (following lecture pattern)
async function runFindQuery(collection, query = {}, options = {}) {
    await initializeConnection();
    const database = client.db(dbName);
    const col = database.collection(collection);
    const cursor = col.find(query, options);
    return await cursor.toArray();
}

// Generic function to insert one document
async function runInsertOneQuery(collection, document) {
    await initializeConnection();
    const database = client.db(dbName);
    const col = database.collection(collection);
    return await col.insertOne(document);
}

// Generic function to update one document
async function runUpdateOneQuery(collection, filter, update) {
    await initializeConnection();
    const database = client.db(dbName);
    const col = database.collection(collection);
    return await col.updateOne(filter, { $set: update });
}

// Generic function to delete one document
async function runDeleteOneQuery(collection, filter) {
    await initializeConnection();
    const database = client.db(dbName);
    const col = database.collection(collection);
    return await col.deleteOne(filter);
}

// Function to find one document
async function runFindOneQuery(collection, query) {
    await initializeConnection();
    const database = client.db(dbName);
    const col = database.collection(collection);
    return await col.findOne(query);
}

module.exports = {
    runFindQuery,
    runInsertOneQuery,
    runUpdateOneQuery,
    runDeleteOneQuery,
    runFindOneQuery,
    initializeConnection,
    client,
    dbName,
    ObjectId
};