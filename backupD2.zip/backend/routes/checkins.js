const express = require('express');
const router = express.Router();
const { runFindQuery, ObjectId } = require('../database');

// List all checkins (with project and user info)
router.get('/', async (req, res) => {
  try {
    // Using MongoClient pattern from lecture
    const checkins = await runFindQuery('checkins', {}, { 
      sort: { createdAt: -1 } 
    });
    
    // Note: For simplicity, not populating user/project here
    // In a real app, you'd do separate queries to get user/project details
    res.json(checkins);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get check-ins for a specific project
router.get('/project/:projectId', async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.projectId)) {
      return res.status(400).json({ error: 'Invalid project ID format' });
    }

    const checkins = await runFindQuery('checkins', {
      project: new ObjectId(req.params.projectId)
    }, {
      sort: { createdAt: -1 },
      limit: 50
    });

    // Populate user details for each checkin
    const checkinsWithUsers = await Promise.all(checkins.map(async (checkin) => {
      try {
        const user = await runFindOneQuery('users', { _id: checkin.user }, { projection: { password: 0 } });
        return { ...checkin, user: user || { name: 'Unknown User', username: 'unknown' } };
      } catch (err) {
        return { ...checkin, user: { name: 'Unknown User', username: 'unknown' } };
      }
    }));

    res.json(checkinsWithUsers);
  } catch (err) {
    console.error('Error fetching project checkins:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get all check-ins (public)
router.get('/project/:projectId', async (req, res) => {
  try {
    const checkins = await runFindQuery('checkins', { 
      project: new ObjectId(req.params.projectId) 
    }, { 
      sort: { createdAt: -1 } 
    });
    res.json(checkins);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get checkins by a specific user
router.get('/user/:userId', async (req, res) => {
  try {
    const checkins = await runFindQuery('checkins', { 
      user: new ObjectId(req.params.userId) 
    }, { 
      sort: { createdAt: -1 } 
    });
    res.json(checkins);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;