const express = require('express');
const router = express.Router();
const multer = require('multer');
const { runFindQuery, runFindOneQuery, runUpdateOneQuery, runDeleteOneQuery, ObjectId } = require('../database');
const auth = require('../middleware/auth');
const path = require('path');
const fs = require('fs');

// Multer setup for profile pictures
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, '..', 'uploads', 'profiles');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, unique + '-' + file.originalname);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 2 * 1024 * 1024 }, // 2MB limit for profile pictures
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed!'), false);
    }
  }
});

// Get all users (public)
router.get('/', async (req, res) => {
  try {
    // Using MongoClient pattern from lecture - get users without password field
    const users = await runFindQuery('users', {}, { 
      projection: { password: 0 }, 
      limit: 100 
    });
    res.json(users);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get user by id
router.get('/:id', async (req, res) => {
  try {
    // Validate ObjectId format
    if (!ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ error: 'Invalid user ID format' });
    }
    
    // Using MongoClient pattern - find user by ObjectId
    const user = await runFindOneQuery('users', { 
      _id: new ObjectId(req.params.id) 
    });
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Remove password from response
    delete user.password;
    
    // Note: For simplicity, not populating friends here
    // In a real app, you'd do a separate query to get friend details
    res.json(user);
  } catch (err) {
    console.error('User fetch error:', err);
    res.status(500).json({ error: 'Server error', details: err.message });
  }
});

// Edit own profile
router.put('/:id', auth, upload.single('profilePicture'), async (req, res) => {
  try {
    console.log('Backend PUT /users/:id - User ID:', req.params.id);
    console.log('Backend PUT /users/:id - Body:', req.body);
    console.log('Backend PUT /users/:id - File:', req.file);
    
    if (req.userId != req.params.id) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    
    const updates = req.body;
    delete updates.password; // Don't change password here
    
    // Handle profile picture upload
    if (req.file) {
      console.log('Profile picture uploaded:', req.file.filename);
      updates.profilePicture = `/uploads/profiles/${req.file.filename}`;
    }
    
    console.log('Updates to apply:', updates);
    
    // Using MongoClient updateOne pattern from lecture
    const result = await runUpdateOneQuery('users', 
      { _id: new ObjectId(req.params.id) }, 
      updates
    );
    
    console.log('Update result:', result);
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Get updated user
    const updatedUser = await runFindOneQuery('users', { 
      _id: new ObjectId(req.params.id) 
    });
    delete updatedUser.password;
    
    console.log('Updated user:', updatedUser);
    res.json(updatedUser);
  } catch (err) {
    console.error('Profile update error:', err);
    res.status(500).json({ error: 'Server error', details: err.message });
  }
});

// Get user's projects (owned and collaborations)
router.get('/:id/projects', async (req, res) => {
  try {
    // Validate ObjectId format
    if (!ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ error: 'Invalid user ID format' });
    }
    
    const userId = new ObjectId(req.params.id);
    
    // Get projects where user is owner or member
    const projects = await runFindQuery('projects', {
      $or: [
        { owner: userId },
        { members: userId }
      ]
    });
    
    res.json(projects || []);
  } catch (err) {
    console.error('Get user projects error:', err);
    res.status(500).json({ error: 'Server error', details: err.message });
  }
});

// Add friend
router.post('/:userId/friends', auth, async (req, res) => {
  try {
    const { friendId } = req.body;
    const userId = req.params.userId;
    
    // Check if user is trying to add themselves
    if (userId === friendId) {
      return res.status(400).json({ error: 'Cannot add yourself as friend' });
    }
    
    // Validate ObjectId formats
    if (!ObjectId.isValid(userId) || !ObjectId.isValid(friendId)) {
      return res.status(400).json({ error: 'Invalid user ID format' });
    }
    
    // Check if friend exists
    const friendUser = await runFindOneQuery('users', { 
      _id: new ObjectId(friendId) 
    });
    
    if (!friendUser) {
      return res.status(404).json({ error: 'Friend user not found' });
    }
    
    // Get current user
    const user = await runFindOneQuery('users', { 
      _id: new ObjectId(userId) 
    });
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Check if already friends
    const currentFriends = user.friends || [];
    if (currentFriends.some(id => id.toString() === friendId)) {
      return res.status(400).json({ error: 'Already friends with this user' });
    }
    
    // Add friend to user's friends list
    const updatedFriends = [...currentFriends, new ObjectId(friendId)];
    await runUpdateOneQuery('users', 
      { _id: new ObjectId(userId) }, 
      { friends: updatedFriends }
    );
    
    res.json({ success: true, message: 'Friend added successfully' });
  } catch (err) {
    console.error('Add friend error:', err);
    res.status(500).json({ error: 'Server error', details: err.message });
  }
});

// Remove friend
router.delete('/:userId/friends/:friendId', auth, async (req, res) => {
  try {
    const { userId, friendId } = req.params;
    
    // Validate ObjectId formats
    if (!ObjectId.isValid(userId) || !ObjectId.isValid(friendId)) {
      return res.status(400).json({ error: 'Invalid user ID format' });
    }
    
    // Get current user
    const user = await runFindOneQuery('users', { 
      _id: new ObjectId(userId) 
    });
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Remove friend from user's friends list
    const currentFriends = user.friends || [];
    const updatedFriends = currentFriends.filter(id => id.toString() !== friendId);
    
    await runUpdateOneQuery('users', 
      { _id: new ObjectId(userId) }, 
      { friends: updatedFriends }
    );
    
    res.json({ success: true, message: 'Friend removed successfully' });
  } catch (err) {
    console.error('Remove friend error:', err);
    res.status(500).json({ error: 'Server error', details: err.message });
  }
});

// Delete profile
router.delete('/:id', auth, async (req, res) => {
  try {
    if (req.userId != req.params.id) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    
    // Using MongoClient deleteOne pattern from lecture
    const result = await runDeleteOneQuery('users', { 
      _id: new ObjectId(req.params.id) 
    });
    
    if (result.deletedCount === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;