const express = require('express');
const router = express.Router();
const { runFindQuery, runInsertOneQuery, runUpdateOneQuery, runDeleteOneQuery, runFindOneQuery, ObjectId } = require('../database');
const auth = require('../middleware/auth');

// Get all posts for a project
router.get('/project/:projectId', async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.projectId)) {
      return res.status(400).json({ error: 'Invalid project ID format' });
    }

    const posts = await runFindQuery('posts', {
      project: new ObjectId(req.params.projectId)
    }, {
      sort: { createdAt: -1 },
      limit: 50
    });

    // Populate user details for each post
    const postsWithUsers = await Promise.all(posts.map(async (post) => {
      try {
        const user = await runFindOneQuery('users', { _id: post.user }, { projection: { password: 0 } });
        return { ...post, user: user || { name: 'Unknown User', username: 'unknown' } };
      } catch (err) {
        return { ...post, user: { name: 'Unknown User', username: 'unknown' } };
      }
    }));

    res.json(postsWithUsers);
  } catch (err) {
    console.error('Error fetching project posts:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create a new post for a project
router.post('/', auth, async (req, res) => {
  try {
    const { projectId, message, type = 'post' } = req.body;

    if (!projectId || !message) {
      return res.status(400).json({ error: 'Project ID and message are required' });
    }

    if (!ObjectId.isValid(projectId)) {
      return res.status(400).json({ error: 'Invalid project ID format' });
    }

    // Verify project exists
    const project = await runFindOneQuery('projects', { _id: new ObjectId(projectId) });
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const newPost = {
      project: new ObjectId(projectId),
      user: new ObjectId(req.userId),
      message: message.trim(),
      type, // 'post', 'update', 'comment'
      createdAt: new Date()
    };

    const result = await runInsertOneQuery('posts', newPost);
    
    // Get the created post with user details
    const createdPost = await runFindOneQuery('posts', { _id: result.insertedId });
    const user = await runFindOneQuery('users', { _id: new ObjectId(req.userId) }, { projection: { password: 0 } });
    
    res.status(201).json({ 
      ...createdPost, 
      user: user || { name: 'Unknown User', username: 'unknown' }
    });
  } catch (err) {
    console.error('Error creating post:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete a post (only by author)
router.delete('/:id', auth, async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ error: 'Invalid post ID format' });
    }

    const post = await runFindOneQuery('posts', { _id: new ObjectId(req.params.id) });
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    // Check if user is the author
    if (post.user.toString() !== req.userId) {
      return res.status(403).json({ error: 'You can only delete your own posts' });
    }

    await runDeleteOneQuery('posts', { _id: new ObjectId(req.params.id) });
    res.json({ success: true });
  } catch (err) {
    console.error('Error deleting post:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;