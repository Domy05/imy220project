const express = require('express');
const router = express.Router();
const { runFindQuery } = require('../database');

// Basic search: ?q=term
router.get('/', async (req, res) => {
  try {
    const q = req.query.q || '';
    const regex = new RegExp(q, 'i');

    // Using MongoClient pattern for search queries
    const users = await runFindQuery('users', { 
      $or: [
        { username: regex }, 
        { name: regex }, 
        { email: regex }
      ] 
    }, { 
      projection: { password: 0 }, 
      limit: 10 
    });

    const projects = await runFindQuery('projects', { 
      $or: [
        { name: regex }, 
        { description: regex }, 
        { hashtags: regex }
      ] 
    }, { 
      limit: 10 
    });

    const checkins = await runFindQuery('checkins', { 
      message: regex 
    }, { 
      limit: 10 
    });

    // Note: For simplicity, not populating related data here
    // In a real app, you'd do separate queries to get user/project details
    res.json({ users, projects, checkins });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;