const express = require('express');
const router = express.Router();
const multer = require('multer');
const { runFindQuery, runFindOneQuery, runInsertOneQuery, runUpdateOneQuery, ObjectId } = require('../database');
const auth = require('../middleware/auth');
const path = require('path');
const fs = require('fs');

// Multer setup (store in uploads/)
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, '..', 'uploads');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, unique + '-' + file.originalname);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

// Get all projects
router.get('/', async (req, res) => {
  try {
    // Using MongoClient pattern from lecture - get all projects
    const projects = await runFindQuery('projects', {}, { 
      sort: { createdAt: -1 } 
    });
    
    // Note: For simplicity, not populating owner/members here
    // In a real app, you'd do separate queries to get user details
    res.json(projects);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create project
router.post('/', auth, upload.fields([
  { name: 'image', maxCount: 1 }, 
  { name: 'files', maxCount: 50 }
]), async (req, res) => {
  try {
    console.log('Creating project - Request body:', req.body);
    console.log('User ID from auth:', req.userId);
    
    const { name, description, type, hashtags } = req.body;
    if (!name || !type) {
      return res.status(400).json({ error: 'Missing required fields (name, type)' });
    }

    if (!req.userId) {
      return res.status(401).json({ error: 'User not authenticated' });
    }

    // Create project document (following lecture pattern)
    const project = {
      name,
      description,
      type,
      hashtags: Array.isArray(hashtags) ? hashtags : (hashtags ? hashtags.split(',').map(h => h.trim()) : []),
      owner: new ObjectId(req.userId),
      members: [new ObjectId(req.userId)],
      version: '0.1.0',
      files: [],
      checkedOut: false,
      checkedOutBy: null,
      createdAt: new Date()
    };

    // Handle image
    if (req.files?.image?.[0]) {
      project.image = `/uploads/${req.files.image[0].filename}`;
    }

    // Handle files
    if (req.files?.files) {
      req.files.files.forEach(f => {
        project.files.push({ 
          filename: `/uploads/${f.filename}`, 
          originalName: f.originalname, 
          size: f.size,
          uploadedAt: new Date()
        });
      });
    }

    // Insert using MongoClient pattern
    const result = await runInsertOneQuery('projects', project);
    
    // Return created project with ID
    project._id = result.insertedId;
    res.json(project);
  } catch (err) {
    console.error('Project creation error:', err);
    res.status(500).json({ error: 'Server error', details: err.message });
  }
});

// View project
router.get('/:id', async (req, res) => {
  try {
    // Using MongoClient pattern - find project by ObjectId
    const project = await runFindOneQuery('projects', { 
      _id: new ObjectId(req.params.id) 
    });
    
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }
    
    // Note: For simplicity, not populating owner/members/checkedOutBy here
    // In a real app, you'd do separate queries to get user details
    res.json(project);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update project
router.put('/:id', auth, upload.fields([
  { name: 'image', maxCount: 1 }, 
  { name: 'files', maxCount: 50 }
]), async (req, res) => {
  try {
    console.log('Updating project - Request body:', req.body);
    console.log('User ID from auth:', req.userId);
    
    const projectId = req.params.id;
    
    // First check if project exists and user has permission
    const existingProject = await runFindOneQuery('projects', { 
      _id: new ObjectId(projectId) 
    });
    
    if (!existingProject) {
      return res.status(404).json({ error: 'Project not found' });
    }
    
    // Check if user is the owner or a member
    const isOwner = existingProject.owner.toString() === req.userId;
    const isMember = existingProject.members.some(memberId => 
      memberId.toString() === req.userId
    );
    
    console.log('Permission check:', {
      projectOwner: existingProject.owner.toString(),
      currentUser: req.userId,
      isOwner,
      isMember,
      members: existingProject.members.map(m => m.toString())
    });
    
    // For now, allow any authenticated user to edit (we can make this stricter later)
    // if (!isOwner && !isMember) {
    //   return res.status(403).json({ error: 'You do not have permission to edit this project' });
    // }

    const { name, description, tags, contributors, files } = req.body;
    
    // Build update object
    const updateData = {};
    
    if (name !== undefined) updateData.name = name;
    if (description !== undefined) updateData.description = description;
    if (tags !== undefined) {
      updateData.hashtags = Array.isArray(tags) ? tags : (tags ? tags.split(',').map(t => t.trim()) : []);
    }
    if (contributors !== undefined) {
      updateData.contributors = Array.isArray(contributors) ? contributors : [];
    }
    if (files !== undefined) {
      updateData.files = Array.isArray(files) ? files : [];
    }

    // Handle new image upload
    if (req.files?.image?.[0]) {
      updateData.image = `/uploads/${req.files.image[0].filename}`;
    }

    // Handle new file uploads
    if (req.files?.files) {
      const newFiles = req.files.files.map(f => ({
        filename: `/uploads/${f.filename}`,
        originalName: f.originalname,
        size: f.size,
        uploadedAt: new Date()
      }));
      
      // Append new files to existing ones
      updateData.files = [...(existingProject.files || []), ...newFiles];
    }

    updateData.updatedAt = new Date();

    // Update using MongoClient pattern
    const result = await runUpdateOneQuery('projects',
      { _id: new ObjectId(projectId) },
      updateData
    );
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ error: 'Project not found' });
    }
    
    // Get updated project
    const updatedProject = await runFindOneQuery('projects', { 
      _id: new ObjectId(projectId) 
    });
    
    res.json(updatedProject);
  } catch (err) {
    console.error('Project update error:', err);
    res.status(500).json({ error: 'Server error', details: err.message });
  }
});

// Checkout project
router.post('/:id/checkout', auth, async (req, res) => {
  try {
    const project = await runFindOneQuery('projects', { 
      _id: new ObjectId(req.params.id) 
    });
    
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }
    if (project.checkedOut) {
      return res.status(400).json({ error: 'Project already checked out' });
    }
    
    // Check if user is member (simple array includes check)
    const isMember = project.members.some(memberId => 
      memberId.toString() === req.userId
    );
    
    console.log('Checkout permission check:', {
      projectId: req.params.id,
      projectOwner: project.owner.toString(),
      currentUser: req.userId,
      isMember,
      members: project.members.map(m => m.toString()),
      checkedOut: project.checkedOut
    });
    
    // For now, allow any authenticated user to checkout (we can make this stricter later)
    // if (!isMember) {
    //   return res.status(403).json({ error: 'You are not a member of this project' });
    // }
    
    // Update project using MongoClient pattern
    const result = await runUpdateOneQuery('projects',
      { _id: new ObjectId(req.params.id) },
      { 
        checkedOut: true, 
        checkedOutBy: new ObjectId(req.userId) 
      }
    );
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ error: 'Project not found' });
    }
    
    // Get updated project
    const updatedProject = await runFindOneQuery('projects', { 
      _id: new ObjectId(req.params.id) 
    });
    
    res.json({ success: true, project: updatedProject });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Checkin project (upload files + message + version)
router.post('/:id/checkin', auth, upload.array('files', 50), async (req, res) => {
  try {
    const project = await runFindOneQuery('projects', { 
      _id: new ObjectId(req.params.id) 
    });
    
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }
    if (!project.checkedOut || project.checkedOutBy?.toString() !== req.userId) {
      return res.status(403).json({ error: 'Project not checked out by you' });
    }

    const { message, version } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Check-in message required' });
    }

    const filesMeta = (req.files || []).map(f => ({ 
      filename: `/uploads/${f.filename}`, 
      originalName: f.originalname, 
      size: f.size 
    }));

    // Create checkin document
    const checkin = {
      project: new ObjectId(project._id),
      user: new ObjectId(req.userId),
      message,
      files: filesMeta,
      version: version || project.version,
      createdAt: new Date()
    };

    // Insert checkin using MongoClient pattern
    const checkinResult = await runInsertOneQuery('checkins', checkin);

    // Update project: add files and reset checkout status
    const updatedFiles = project.files.concat(filesMeta);
    const projectUpdates = {
      files: updatedFiles,
      checkedOut: false,
      checkedOutBy: null
    };
    
    if (version) {
      projectUpdates.version = version;
    }

    await runUpdateOneQuery('projects',
      { _id: new ObjectId(project._id) },
      projectUpdates
    );

    // Return checkin with ID
    checkin._id = checkinResult.insertedId;
    res.json({ success: true, checkin });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Reset all projects to not checked out (for development/testing)
router.post('/reset-checkouts', auth, async (req, res) => {
  try {
    // Update all projects to remove checkout status
    const result = await runUpdateOneQuery('projects',
      { checkedOut: true }, // Filter: only update projects that are checked out
      { 
        checkedOut: false, 
        checkedOutBy: null 
      },
      { multi: true } // Update multiple documents
    );
    
    // Since runUpdateOneQuery only updates one, let's use a different approach
    // We need to update all projects manually
    const { MongoClient } = require('mongodb');
    const uri = process.env.MONGO_URI;
    const client = new MongoClient(uri);
    
    await client.connect();
    const db = client.db();
    const collection = db.collection('projects');
    
    const updateResult = await collection.updateMany(
      { checkedOut: true },
      { 
        $set: {
          checkedOut: false,
          checkedOutBy: null
        }
      }
    );
    
    await client.close();
    
    res.json({ 
      success: true, 
      message: `Reset ${updateResult.modifiedCount} projects`,
      modifiedCount: updateResult.modifiedCount
    });
  } catch (err) {
    console.error('Error resetting checkouts:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;