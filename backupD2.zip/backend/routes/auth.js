const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { runFindOneQuery, runInsertOneQuery } = require('../database');

// Create account (signup)
router.post('/register', async (req, res) => {
  try {
    const { username, email, password, name, bio } = req.body;
    if (!username || !email || !password || !name) {
      return res.status(400).json({ error: 'Missing required fields: username, email, password, and name are required' });
    }
    
    // Check if user already exists (following lecture pattern)
    const existingUser = await runFindOneQuery('users', { 
      $or: [{ email }, { username }] 
    });
    
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    // Create new user document (following lecture pattern)
    const newUser = {
      username,
      email,
      password, // Not hashed as per assignment specification
      name,
      bio: bio || '',
      profileImage: '',
      friends: [],
      createdAt: new Date(),
      role: 'user'
    };

    const result = await runInsertOneQuery('users', newUser);
    
    // Sign token
    const token = jwt.sign({ id: result.insertedId }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.cookie('token', token, { httpOnly: true, sameSite: 'lax' });
    res.json({ 
      success: true,
      user: { id: result.insertedId, username, email, name } 
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Find user using MongoClient pattern
    const user = await runFindOneQuery('users', { email, password });
    
    if (!user) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }
    
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.cookie('token', token, { httpOnly: true, sameSite: 'lax' });
    res.json({ 
      success: true,
      user: { id: user._id, username: user.username, email: user.email, name: user.name } 
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Logout
router.post('/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ success: true });
});

module.exports = router;