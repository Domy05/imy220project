require('dotenv').config();
const { MongoClient } = require('mongodb');

async function resetCheckouts() {
  const uri = process.env.MONGO_URI;
  const client = new MongoClient(uri);
  
  try {
    await client.connect();
    console.log('Connected to MongoDB');
    
    const db = client.db();
    const collection = db.collection('projects');
    
    // Update all projects to remove checkout status
    const result = await collection.updateMany(
      { checkedOut: true },
      { 
        $set: {
          checkedOut: false,
          checkedOutBy: null
        }
      }
    );
    
    console.log(`Reset ${result.modifiedCount} projects`);
    console.log('All projects are now available for checkout');
    
  } catch (error) {
    console.error('Error resetting checkouts:', error);
  } finally {
    await client.close();
  }
}

resetCheckouts();